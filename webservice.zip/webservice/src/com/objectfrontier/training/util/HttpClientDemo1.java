/**
 * 
 */
package com.objectfrontier.training.util;

import javax.servlet.http.HttpServlet;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.api.Person;
import com.objectfrontier.training.servlet.RequestHelper;

/**
 * @author kamalesh.murali
 * @since Nov 12, 2018
 */
public class HttpClientDemo1 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public void run() throws Exception {
//        String url = "http://localhost:8080/ws/addressServlet?id=1";
//        RequestHelper requestHelper = new RequestHelper();
//        requestHelper.setUri(url);
//        requestHelper.setMethod(HttpMethod.DELETE);
//        System.out.println(requestHelper.requestString());
        String url = "http://localhost:8080/ws/addressServlet?userName=kamal@gmail.com&passWord=kamal";
        Address input = new Address();
        input.setStreet("sami street");
        input.setCity(null);
        input.setPostalCode(600001);

        String output = new RequestHelper()
                           .setMethod(HttpMethod.PUT)
                           .setInput(input)
                           .requestString(url);
        System.out.println(output);
    }

    public static void main(String[] args) throws Exception {
        HttpClientDemo1 obj = new HttpClientDemo1();
        obj.run();
    }
}
