/**
 * 
 */
package com.objectfrontier.training.api;

import java.util.ArrayList;

/**
 * @author kamalesh.murali
 * @since Nov 17, 2018
 */
public interface AddressAbstract {

    long create(Address address);
    Address update(Address address);
    Address delete(Address address);
    Address read(long id);
    ArrayList<Address> readAll();
    ArrayList<Address> search(String[] fields, String searchInput);

}
