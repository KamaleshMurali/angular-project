/**
 * 
 */
package com.objectfrontier.training.api;

/**
 * @author kamalesh.murali
 * @since Oct 12, 2018
 */
public enum AppErrorCode {

    INVALID_PERSON_ID(100, "id is empty"),
    INVALID_FIRST_NAME(101, "First_Name is empty"),
    INVALID_LAST_NAME(102, "Last_Name is empty"),
    INVALID_EMAIL_ADDRESS(103, "Email_Address is empty"),
    INVALID_BIRTH_DATE(104, "Birth_Date is empty"),
    DUPLICATE_EMAIL_ID(105, "email id is duplicated"),
    DUPLICATED_FIRST_NAME_AND_LAST_NAME(106, "First name and Last name are duplicated"),
    INVALID_FIRST_NAME_AND_LAST_NAME(107, "First name and Last name is empty"),
    PERSON_NOT_FOUND(108, "Person not Found"),
    ERROR_CONSTRUCT_PERSON(109, "Error in Construct Person"),
    INVALID_ADDRESS_ID(200, "id is empty"),
    INVALID_STREET_NAME(201, "street is empty"),
    INVALID_CITY_NAME(202, "city is empty"),
    INVALID_POSTAL_CODE(203, "postal code is empty"),
    ADDRESS_NOT_FOUND(204, "Addess not Found"),
    ERROR_CONSTRUCT_ADDRESS(205, "Error in Construct Address"),
    FAILED_TO_AUTO_INCREMENT(300, "auto increment is failed"),
    INVALID_SEARCH_INPUT(500, "search input is empty"),
    INVALID_FIELD_NAME(501, "field name is empty"),
    ERROR_CREATE_PERSON(700, "Error in create"),
    ERROR_UPDATE_PERSON(701, "Error in update"),
    ERROR_DELETE_PERSON(702, "Error in delete"),
    ERROR_READ_PERSON_WITH_ADDRESS(703, "Error in read"),
    ERROR_READ_PERSON(704, "Error in read"),
    ERROR_READALL_PERSON(705, "Error in readAll"),
    ERROR_READALL_PERSON_WITH_ADDRESS(706, "Error in readAll"),
    ERROR_DUPLICATE_EMAIL_ID(707,"Error in duplicate email id"),
    ERROR_DUPLICATE_NAME(708, "Error in duplicate name"),
    ERROR_CREATE_ADDRESS(800, "Error in create address"),
    ERROR_UPDATE_ADDRESS(801, "Error in update address"),
    ERROR_DELETE_ADDRESS(802, "Error in delete address"),
    ERROR_READ_ADDRESS(803, "Error in read address"),
    ERROR_READALL_ADDRESS(804, "Error in readAll address"),
    ERROR_SEARCH_ADDRESS(805, "Error in search address"),
    ERROR_CREATE_CONNECTION(400, "Error in connection creation"),
    ERROR_RELEASE_CONNECTION(401, "Error in release connection"),
    ERROR_LOAD_PROPERTIES(402, "Error in loading properties"),
    ERROR_NUMBER_FORMAT_EXCEPTION(403, "id need to be a number"),
    INVALID_USER_NAME(150, "Username is empty"),
    INVALID_PASSWORD(151, "Password is empty"),
    INVALID_INPUT(156, "Input is invalid"),
    AUTHENTICATION_FAILED(152, "wrong username and password"),
    UN_AUTHORIZED_OPERATION(153, "Not an authorized person"),
    LOGIN_ERROR(154, "Error in Login method"),
    UN_AUTHENTICATED_USER(156, "Unauthenticated user"),
    SESSION_NOT_CREATED(155, "session not created"),
    INTERNAL_SERVER_ERROR(500, "Internal server error");

    private final int errorId;
    private final String errorMessage;

    /**
     * @param errorId
     * @param errorMessage
     */
    private AppErrorCode(int errorId, String errorMessage) {
        this.errorId = errorId;
        this.errorMessage = errorMessage;
    }

    public int getErrorId() {
        return errorId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
