/**
 * 
 */
package com.objectfrontier.training.api;

import java.util.ArrayList;

/**
 * @author kamalesh.murali
 * @since Oct 5, 2018
 */
public class AppException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ArrayList<AppErrorCode> errorCodes;
    public AppErrorCode errorCode;
    Throwable cause;

    public AppException(ArrayList<AppErrorCode> errorCodes) {
        super();
        this.errorCodes = errorCodes;
    }

    public AppException(AppErrorCode errorCode, Throwable cause) {
        super(cause);
        errorCodes = new ArrayList<>();
        errorCodes.add(errorCode);
        this.errorCode = errorCode;
        this.cause = cause;
    }

    public AppException(AppErrorCode errorCode) {
        super();
        errorCodes = new ArrayList<>();
        errorCodes.add(errorCode);
        this.errorCode = errorCode;
    }

    public ArrayList<AppErrorCode> getErrorCodes() {
        return errorCodes;
    }

    public void setErrorCodes(ArrayList<AppErrorCode> errorCodes) {
        this.errorCodes = errorCodes;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((errorCodes == null) ? 0 : errorCodes.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AppException other = (AppException) obj;
        if (errorCodes == null) {
            if (other.errorCodes != null)
                return false;
        } else if (!errorCodes.equals(other.errorCodes))
            return false;
        return true;
    }

//    @Override
//    public String toString() {
//        StringBuilder builder = new StringBuilder();
//        builder.append("AppException [errorCodes=");
//        builder.append(errorCodes);
//        builder.append(", errorCode=");
//        builder.append(errorCode);
//        builder.append(", cause=");
//        builder.append(cause);
//        builder.append("]");
//        return builder.toString();
//    }

//    @Override
//    public String toString() {
//        StringBuilder builder = new StringBuilder();
//        builder.append("AppException [errorCodes=");
//        builder.append(errorCodes);
//        builder.append("]");
//        return builder.toString();
//    }

}

