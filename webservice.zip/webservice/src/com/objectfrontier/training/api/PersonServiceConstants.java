/**dd
 * 
 */
package com.objectfrontier.training.api;

/**
 * @author kamalesh.murali
 * @since Nov 19, 2018
 */
public interface PersonServiceConstants {

    public static final String insert = new StringBuilder("INSERT INTO PERSON(`first_name`")
                                                .append(", `last_name`                  ")
                                                .append(", `email`                      ")
                                                .append(", `address_id`                 ")
                                                .append(", `birth_date`)                ")
                                                .append(" VALUES (?, ?, ?, ?, ?);       ")
                                                .toString();

    public static final String delete = "Delete FROM person WHERE id = ?";

    public static final String update =  new StringBuilder("UPDATE person SET first_name = ?")
                                            .append(", last_name = ?, email = ?      ")
                                            .append(", address_id = ?, birth_date = ?")
                                            .append(" WHERE id = ?;                  ")
                                            .toString();          

    public static final String readWithAddress =  new StringBuilder("SELECT id    ")
                                                     .append(", first_name ")
                                                     .append(", last_name  ")
                                                     .append(", email      ")
                                                     .append(", birth_date ")
                                                     .append(", address_id ")
                                                     .append(", created_date") 
                                                     .append(" FROM person ")
                                                     .append(" WHERE id = ?")
                                                     .toString(); 

    public static final String read = new StringBuilder("SELECT id, first_name,    ")
                                         .append(" last_name, email,        ")
                                         .append(" address_id, birth_date   ")
                                         .append(" FROM person WHERE id = ?;")
                                         .toString();      

    public static final String readAllWithAddress =  new StringBuilder("SELECT id   ")
                                                        .append(", first_name")
                                                        .append(", last_name ")
                                                        .append(", email     ")
                                                        .append(", birth_date")
                                                        .append(", address_id")
                                                        .append(" FROM person")
                                                        .toString();    

    public static final String readAll =  new StringBuilder("SELECT id, first_name, ")
                                             .append(" last_name, email,     ")
                                             .append(" address_id, birth_date")
                                             .append(" FROM person;          ")
                                             .toString();       

    public static final String EmailCountForUpdate =  new StringBuilder()                           
                                                         .append("SELECT COUNT(email) FROM person ")
                                                         .append("WHERE email = ? AND id != ?;    ")
                                                         .toString();                               

    public static final String EmailCountForCreate = new StringBuilder()                           
                                                        .append("SELECT COUNT(email) FROM person ")
                                                        .append("WHERE email = ?;                ")
                                                        .toString();                               

    public static final String DuplicateNamesCountForUpdate = new StringBuilder()                                  
                                                                 .append("SELECT COUNT(*) FROM person            ")
                                                                 .append("WHERE first_name = ? AND last_name = ? ")
                                                                 .append("AND id != ?                            ")
                                                                 .toString();                                      

    public static final String DuplicateNamesCountForCreate = new StringBuilder()                                  
                                                                 .append("SELECT COUNT(*) FROM person            ")
                                                                 .append("WHERE first_name = ? AND last_name = ?;")
                                                                 .toString();  

    public static final String id = "id";

    public static final String firstName = "first_name";

    public static final String lastName = "last_name";

    public static final String email = "email";

    public static final String addressId = "address_id";

    public static final String birthDate = "birth_date";

    public static final String createdDate = "created_date";

}
