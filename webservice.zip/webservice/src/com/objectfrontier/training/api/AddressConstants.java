/**
 * 
 */
package com.objectfrontier.training.api;

/**
 * @author kamalesh.murali
 * @since Nov 17, 2018
 */
public interface AddressConstants {

    public static final String createQuery = "INSERT INTO ADDRESS(`street`, `city`, `postal_code`) VALUES (?, ?, ?)";

    public static final String updateQuery = "UPDATE address SET street = ?, city = ?, postal_code = ? WHERE id = ?";

    public static final String deleteQuery = "Delete FROM address WHERE id = ?";

    public static final String readQuery = "SELECT id, street, city, postal_code FROM address WHERE id = ?;";

    public static final String readAllQuery = "SELECT id, street, city, postal_code FROM address;";

    public static final String id = "id";

    public static final String street = "street";

    public static final String city = "city";

    public static final String postalCode = "postal_code";

}
