/**
 * 
 */
package com.objectfrontier.training.api;

import java.util.ArrayList;

/**
 * @author kamalesh.murali
 * @since Nov 27, 2018
 */
public interface PersonAbstract {

    long create(Person person);
    Person update(Person person);
    long delete(long id);
    Person read(boolean includeAddress, long id);
    Person readWithAddress(long id);
    Person readWithoutAddress(long id);
    ArrayList<Person> readAll(boolean includeAddress);
    ArrayList<Person> readAllWithAddress();
    ArrayList<Person> readAllWithoutAddress();
}
