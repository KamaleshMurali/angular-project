/**
 * 
 */
package com.objectfrontier.training.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.util.JsonUtil;

/**
 * @author kamalesh.murali
 * @since Nov 24, 2018
 */
public class ErrorFilter implements Filter {

    @Override
    public void destroy() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletResponse response = (HttpServletResponse) res;  
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE, PUT");
        response.setHeader("Access-Control-Allow-headers", "*");
        PrintWriter writer = response.getWriter();
        try {
            chain.doFilter(req, res);
        } catch(Exception e) {
            AppException e1 = (AppException) e;
            if (Objects.nonNull(e1)) {  
                response.setStatus(200);
                writer.write(JsonUtil.toJson(e1.getErrorCodes()));
            } else {
                response.setStatus(500);
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                writer.write(JsonUtil.toJson(e));
            }
        } finally {
            writer.close();
        }
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
        
    }

}
