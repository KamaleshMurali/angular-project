/**
 * 
 */
package com.objectfrontier.training.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.api.AppErrorCode;
import com.objectfrontier.training.api.AppException;

/**
 * @author kamalesh.murali
 * @since Nov 19, 2018
 */
public class AuthenticationFilter implements Filter {

    @Override
    public void init(FilterConfig arg0) throws ServletException {}

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        PrintWriter writer = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session.equals(null)) {
            throw new AppException(AppErrorCode.SESSION_NOT_CREATED);
        }
        Object id = session.getAttribute("sessionId");
        Object person = session.getAttribute("person");
        if (Objects.isNull(id) || Objects.isNull(person)) {
            response.setStatus(403);
            throw new AppException(AppErrorCode.UN_AUTHENTICATED_USER);
        }
        chain.doFilter(req, res);
        writer.close();
    }

    @Override
    public void destroy() {
        
    }
}
