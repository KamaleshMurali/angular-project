/**
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
package com.objectfrontier.training.servlet;

import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import com.objectfrontier.training.util.AppErrCode;
import com.objectfrontier.training.util.AppException;
import com.objectfrontier.training.util.HttpMethod;
import com.objectfrontier.training.util.JsonUtil;

/**
 * @author prassie
 * @since  Oct 03, 2006
 */
public class RequestHelper {

    public static RequestHelper init() { return new RequestHelper(); }

    private String uri;
    private HttpMethod method = HttpMethod.GET;
    private Map<String, String> headers;
    private Object input;

    public RequestHelper setUri	   (String 			    uri	   ) { this.uri 	= uri;     return this; }
    public RequestHelper setMethod (HttpMethod 			method ) { this.method  = method;  return this; }
    public RequestHelper setHeaders(Map<String, String> headers) { this.headers = headers; return this; }
    public RequestHelper setInput  (Object 			    input  ) { this.input   = input;   return this; }

    public HttpUriRequest build(String uri) throws Exception { this.uri = uri; return build(); }
    public HttpUriRequest build() throws Exception {

        HttpUriRequest request = method.build(uri);

        if (headers != null) {
            headers.forEach((k, v) -> request.addHeader(k, v));
        }

        if (input != null) {
            StringEntity inputEntity = new StringEntity(JsonUtil.toJson(input));
            inputEntity.setContentType(ContentType.APPLICATION_JSON.getMimeType());
            HttpEntityEnclosingRequest entityRequest = (HttpEntityEnclosingRequest) request;
            entityRequest.setEntity(inputEntity);
        }

        return request;
    }

    public HttpEntity requestRaw() throws Exception {
        HttpUriRequest request = build();
        HttpResponse response = HttpClientBuilder.create().build().execute(request);
        HttpEntity responseEntity = handleResponse(response);
        return responseEntity;
    }

    private static HttpEntity handleResponse(HttpResponse response) {

        int responseStatusCode = response.getStatusLine().getStatusCode();
        HttpEntity entity = response.getEntity();

        // success responses
        if (responseStatusCode < 300) { return entity; }

        // failure responses
        List<AppErrCode> errorCodes;
        try {
            String errResponse = EntityUtils.toString(entity);
            errorCodes = JsonUtil.toList(errResponse, AppErrCode.class);
        } catch (Exception e) {
            throw new AppException(e);
        }

        throw new AppException(errorCodes);
    }

    public String requestString(String uri) throws Exception { this.uri = uri; return requestString(); }
    public String requestString() throws Exception { return EntityUtils.toString(requestRaw()); }

    public <T> T requestObject(String uri, Class<? extends T> type) throws Exception { this.uri = uri; return requestObject(type); }
    public <T> T requestObject(Class<? extends T> type) throws Exception {
        return JsonUtil.toObject(EntityUtils.toString(requestRaw()), type);
    }
}
