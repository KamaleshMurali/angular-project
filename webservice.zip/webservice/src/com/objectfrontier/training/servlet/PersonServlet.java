/**
 * 
 */
package com.objectfrontier.training.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.api.AppErrorCode;
import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.api.Person;
import com.objectfrontier.training.api.PersonAbstract;
import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.util.JsonUtil;

/**
 * @author kamalesh.murali
 * @since Nov 1, 2018
 */
public class PersonServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        PersonAbstract personService = new PersonService();

        response.setContentType("application/json");
        String id = request.getParameter("id");
        String includeAddress = request.getParameter("address");
        PrintWriter writer = response.getWriter();

        if (Objects.isNull(id)) {

            ArrayList<Person> persons = personService.readAll(Boolean.parseBoolean(includeAddress));
            writer.write(JsonUtil.toJson(persons));
        } else {
            try {
                Person person = personService.read(Boolean.parseBoolean(includeAddress), Long.parseLong(id));
                writer.write(JsonUtil.toJson(person));
            } catch (NumberFormatException e) {
                throw new AppException(AppErrorCode.INVALID_PERSON_ID);
            }
        }
        writer.close();
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        String id = request.getParameter("id");
        PrintWriter writer = response.getWriter();

        PersonAbstract personService = new PersonService();

//        Address address = new Address();
//        address.setId(Long.parseLong(id));
        long addr = personService.delete(Long.parseLong(id));
        writer.write(JsonUtil.toJson(addr));
        writer.close();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

        response.setContentType("application/json");

        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String personJson = String.join("", jsonLines);

        Person person = JsonUtil.toObject(personJson, Person.class);
        PersonAbstract personService = new PersonService();
        PrintWriter writer = response.getWriter();

        Person pers = personService.update(person);
        writer.write(JsonUtil.toJson(pers));
        writer.close();
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");

        //Reading payload(Input) as JSON using reader

        PrintWriter writer = response.getWriter();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String personJson = String.join("", jsonLines);

        //Converting JSON to Object

        Person person = JsonUtil.toObject(personJson, Person.class);

        PersonAbstract personService = new PersonService();

        long personId = personService.create(person);
        writer.write(JsonUtil.toJson(personId));
        writer.close();
    }
}
