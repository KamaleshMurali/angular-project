/**
 * 
 */
package com.objectfrontier.training.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.api.AddressAbstract;
import com.objectfrontier.training.api.AppErrorCode;
import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.util.JsonUtil;

/**
 * @author kamalesh.murali
 * @since Oct 31, 2018
 */
public class AddressServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        ArrayList<Address> addresses = null;
        String id = request.getParameter("id");
        PrintWriter writer = response.getWriter();

        String search = request.getParameter("search");
        String searchFields = request.getParameter("searchFields");
        String searchInput = request.getParameter("searchInput");

        AddressAbstract addressService = new AddressService();
        if (Boolean.parseBoolean(search)) {
            String[] fields = searchFields.split(",");
            ArrayList<Address> searchResult = addressService.search(fields, searchInput);
            writer.write(JsonUtil.toJson(searchResult));
            writer.close();
        }
 
        if (id != null) {
            Address address = null;
            writer = response.getWriter();
            try {
                address = addressService.read(Long.parseLong(id));
                writer.write(JsonUtil.toJson(address));
            } catch (NumberFormatException e) {
                throw new AppException(AppErrorCode.INVALID_ADDRESS_ID);
            }
        } else {
            addresses = addressService.readAll();
        }
        writer.write(JsonUtil.toJson(addresses));

        writer.close();
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        PrintWriter writer = response.getWriter();
        String id = request.getParameter("id");

        AddressAbstract addressService = new AddressService();

        Address address = new Address();
        address.setId(Long.parseLong(id));
        Address addr = addressService.delete(address);

        writer.write(JsonUtil.toJson(addr));
        writer.close();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        PrintWriter writer = response.getWriter();

        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String addressJson = String.join("", jsonLines);

        Address address = JsonUtil.toObject(addressJson, Address.class);
        AddressAbstract addressService = new AddressService();

        Address addr = addressService.update(address);

        writer.write(JsonUtil.toJson(addr));
        writer.close();
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");

        //Reading payload(Input) as JSON using reader
        PrintWriter writer = response.getWriter();

        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String addressJson = String.join("", jsonLines);
        System.out.format("Input JSON >> %s", addressJson);

        //Converting JSON to Object

        Address address = JsonUtil.toObject(addressJson, Address.class);
        AddressAbstract addressService = new AddressService();

        long addressId = addressService.create(address);
        writer.write(JsonUtil.toJson(addressId));
        writer.close();
    }

    private void responseWriter(HttpServletResponse response, Object value) {
        PrintWriter writer = null;
        try {
            writer = response.getWriter();
        } catch (Exception e) {
            writer.write(e.getMessage());
        }
    }
}