/**
 * 
 */
package com.objectfrontier.training.servlet;

import java.sql.Connection;

import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.api.AppErrorCode;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * @author kamalesh.murali
 * @since Nov 14, 2018
 */
public class ConnectionService {


    private static HikariDataSource ds;
 
    private static HikariConfig config = new HikariConfig("resources/hikariProperties.properties");

    static {
        ds = new HikariDataSource(config);
    }
     
    public static Connection initConnection() {
        try {
            return ds.getConnection();
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_CREATE_CONNECTION, e);
        }
    }


    public static void releaseConnection(boolean doCommit) {
        Connection connection = getConnection();
        try {
            if (doCommit) {
                connection.commit();
            } else {
                connection.rollback();
            }
            connection.close();
        } catch(Exception e) {
            throw new AppException(AppErrorCode.ERROR_RELEASE_CONNECTION, e);
        }
    }

    private ConnectionService() {
    }

    public static void clear() {
        value.remove();
    }

    private static ThreadLocal<Connection> value = new ThreadLocal<Connection>() {

        protected Connection initialValue() {
            return initConnection();
        }
    };

    public static Connection getConnection() {
        return value.get();
    }
}
