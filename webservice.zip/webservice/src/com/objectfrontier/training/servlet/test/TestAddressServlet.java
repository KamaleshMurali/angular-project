/**
 * 
 */
package com.objectfrontier.training.servlet.test;

import javax.servlet.http.HttpServlet;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.servlet.RequestHelper;
import com.objectfrontier.training.util.HttpMethod;
import com.objectfrontier.training.util.JsonUtil;

/**
 * @author kamalesh.murali
 * @since Nov 7, 2018
 */
public class TestAddressServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @BeforeClass
    private void setUp() {
        
    }

    @Test(dataProvider = "testDoGetPositiveDP")
    private void testDoGetPositive(String url, Address expected) throws Exception {

        try {
            Address actual = new RequestHelper()
                                .setMethod(HttpMethod.GET)
                                .requestObject(url, Address.class);

            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
        } catch (Exception e) {
            Assert.fail(e.getMessage());
            e.printStackTrace();
        }
    }

    @DataProvider
    private Object[][] testDoGetPositiveDP() {

        Address addressOne = new Address();
        addressOne.setId(1l);
        addressOne.setStreet("siva street");
        addressOne.setCity("tirchy");
        addressOne.setPostalCode(600555);

        Address addressTwo = new Address();
        addressTwo.setId(97l);
        addressTwo.setStreet("ram street");
        addressTwo.setCity("chennai");
        addressTwo.setPostalCode(600001);
        return new Object[][] {
            {"http://localhost:8080/ws/addressServlet?id=1", addressOne},
            {"http://localhost:8080/ws/addressServlet?id=97", addressTwo}
        };
    }

    @Test(dataProvider = "testDoDeletePositiveDP")
    private void testDoDeletePositive(String url, Address expected) throws Exception {
        try {
            Address actual = new RequestHelper()
                                .setMethod(HttpMethod.DELETE)
                                .requestObject(url, Address.class);
//            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
        } catch (Exception e) {
            Assert.fail("error occured in doDelete method");
            e.printStackTrace();
        }
    }

    @DataProvider
    private Object[][] testDoDeletePositiveDP() {

        Address addressOne = new Address();
        addressOne.setId(97l);

        Address addressTwo = new Address();
        addressTwo.setId(98l);

        return new Object[][] {
//            {"http://localhost:8080/ws/addressServlet?id=97", addressOne},
            {"http://localhost:8080/ws/addressServlet?id=61", addressTwo}
        };
    }

    @Test(dataProvider = "testDoPutPositiveDP")
    private void testDoPutPositive(String url, Address input) throws Exception {
        try {
            long actual = new RequestHelper()
                                .setMethod(HttpMethod.PUT)
                                .setInput(input)
                                .requestObject(url, Long.class);
            Assert.assertTrue(actual > 0, "address not created");
        } catch (Exception e) {
            Assert.fail("error occured in doPut method");
            e.printStackTrace();
        }
    }

    @DataProvider
    private Object[][] testDoPutPositiveDP() {

        Address addressOne = new Address();
        addressOne.setStreet("ram street");
        addressOne.setCity("chennai");
        addressOne.setPostalCode(600001);

        Address addressTwo = new Address();
        addressTwo.setStreet("ram street");
        addressTwo.setCity("chennai");
        addressTwo.setPostalCode(600001);

        return new Object[][] {
            {"http://localhost:8080/ws/addressServlet", addressOne},
            {"http://localhost:8080/ws/addressServlet", addressTwo}
        };
    }

    @Test(dataProvider = "testDoPostPositiveDP")
    private void testDoPostPositive(String url, Address input) throws Exception {
        try {
            Address actual = new RequestHelper()
                                .setMethod(HttpMethod.POST)
                                .setInput(input)
                                .requestObject(url, Address.class);

            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
        } catch (Exception e) {
            Assert.fail(e.getMessage());
            e.printStackTrace();
        }
    }

    @DataProvider
    private Object[][] testDoPostPositiveDP() {

        Address addressOne = new Address();
        addressOne.setId(65l);
        addressOne.setStreet("ram street");
        addressOne.setCity("chennai");
        addressOne.setPostalCode(600001);

        Address addressTwo = new Address();
        addressTwo.setId(90l);
        addressTwo.setStreet("ram street");
        addressTwo.setCity("chennai");
        addressTwo.setPostalCode(600001);

        return new Object[][] {
            {"http://localhost:8080/ws/addressServlet", addressOne},
            {"http://localhost:8080/ws/addressServlet", addressTwo}
        };
    }
//    private void log(String values, Object... args) {
//        System.out.format(values, args);
//    }

    @Test
    private void testDoGetNegative() throws Exception {
            String url = "http://localhost:8080/ws/addressServlet?id=1000";
            String actual = new RequestHelper()
                                .setMethod(HttpMethod.GET)
                                .requestString(url);
            System.out.println(actual);
    }

    @Test(dataProvider = "testDoPutNegativeDP")
    private void testDoPutNegative(String url, Address input) throws Exception {
        String actual = new RequestHelper()
                            .setMethod(HttpMethod.PUT)
                            .setInput(input)
                            .requestString(url);
        System.out.println(JsonUtil.toJson(actual));
            
    }

    @DataProvider
    private Object[][] testDoPutNegativeDP() {

        Address addressTwo = new Address();
        addressTwo.setStreet("palani street");
        addressTwo.setCity("chennai");
        addressTwo.setPostalCode(null);

        return new Object[][] {
            {"http://localhost:8080/ws/addressServlet?userName=kamal@gmail.com&passWord=kamal", addressTwo}
        };
    }
    
    
    @Test(dataProvider = "testDoDeleteNegativeDP")
    private void testDoDeleteNegative(String url, Address expected) throws Exception {
            Address actual = new RequestHelper()
                                .setMethod(HttpMethod.DELETE)
                                .requestObject(url, Address.class);
            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testDoDeleteNegativeDP() {

        Address addressOne = new Address();
        addressOne.setId(97l);

        Address addressTwo = new Address();
        addressTwo.setId(98l);

        return new Object[][] {
            {"http://localhost:8080/ws/addressServlet?id=97", addressOne},
            {"http://localhost:8080/ws/addressServlet?id=98", addressTwo}
        };
    }

    @AfterClass
    private void tearDown() {
        
    }
}
