/**
 * 
 */
package com.objectfrontier.training.servlet.test;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServlet;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.api.Person;
import com.objectfrontier.training.servlet.RequestHelper;
import com.objectfrontier.training.util.HttpMethod;
import com.objectfrontier.training.util.JsonUtil;

/**
 * @author kamalesh.murali
 * @since Nov 13, 2018
 */
public class TestPersonServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @AfterClass
    private void setUp() {
        
    }

    @Test(dataProvider = "testDoGetPositiveDP")
    private void testDoGetPositive(String url, Person expected) throws Exception {

        try {
            Person actual = new RequestHelper()
                               .setMethod(HttpMethod.GET)
                               .requestObject(url, Person.class);

            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @DataProvider
    private Object[][] testDoGetPositiveDP() {

        Person personOne = new Person();
        personOne.setId(1l);
        personOne.setFirstName("murali");
        personOne.setLastName("murugan");
        personOne.setEmail("murali@gmail.com");
        personOne.setAddressId(91l);
        personOne.setBirthDate(Date.valueOf("1996-08-27"));

        Person personTwo = new Person();
        personTwo.setId(2l);
        personTwo.setFirstName("vidhyaa");
        personTwo.setLastName("masilamani");
        personTwo.setEmail("vidhyaa@gmail.com");
        personTwo.setAddressId(92l);
        personTwo.setBirthDate(Date.valueOf("1997-09-15"));
        return new Object[][] {
            {"http://localhost:8080/ws/personServlet?id=abc", personOne},
            {"http://localhost:8080/ws/personServlet?id=2", personTwo}
        };
    }

    
    @Test(dataProvider = "testDoDeletePositiveDP")
    private void testDoDeletePositive(String url, long expectedValue) throws Exception {
        try {
            long actual = new RequestHelper()
                                .setMethod(HttpMethod.DELETE)
                                .requestObject(url, long.class);
            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expectedValue));
        } catch (Exception e) {
            Assert.fail("error occured in doDelete method");
            e.printStackTrace();
        }
    }

    @DataProvider
    private Object[][] testDoDeletePositiveDP() {

        return new Object[][] {
            {"http://localhost:8080/ws/personServlet?id=20", 20},
            {"http://localhost:8080/ws/personServlet?id=21", 21}
        };
    }

    @Test(dataProvider = "testDoPutPositiveDP")
    private void testDoPutPositive(String url, Person input) throws Exception {
        try {
            long actual = new RequestHelper()
                                .setMethod(HttpMethod.PUT)
                                .setInput(input)
                                .requestObject(url, long.class);
            Assert.assertTrue(actual > 0, "person not created");
        } catch (Exception e) {
            Assert.fail("error occured in doPut method");
            e.printStackTrace();
        }
    }

    @DataProvider
    private Object[][] testDoPutPositiveDP() {

        Person personOne = new Person();
        personOne.setFirstName("padmavathy");
        personOne.setLastName("murali");
        personOne.setEmail("padma@gmail.com");
        personOne.setBirthDate(Date.valueOf("1997-05-05"));

        Address addressOne = new Address();
        addressOne.setStreet("kannagi street");
        addressOne.setCity("chennai");
        addressOne.setPostalCode(600001);

        personOne.setAddress(addressOne);

        Person personTwo = new Person();
        personTwo.setFirstName("kanchana");
        personTwo.setLastName("sivamani");
        personTwo.setEmail("kanchana@gmail.com");
        personTwo.setBirthDate(Date.valueOf("1997-06-23"));

        Address addressTwo = new Address();
        addressTwo.setStreet("kannan street");
        addressTwo.setCity("chennai");
        addressTwo.setPostalCode(600011);

        personTwo.setAddress(addressTwo);

        return new Object[][] {
            {"http://localhost:8080/ws/personServlet", personOne},
            {"http://localhost:8080/ws/personServlet", personTwo}
        };
    }

    @Test(dataProvider = "testDoPostPositiveDP")
    private void testDoPostPositive(String url, Person input) throws Exception {
        try {
            Person actual = new RequestHelper()
                                .setMethod(HttpMethod.POST)
                                .setInput(input)
                                .requestObject(url, Person.class);

            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
        } catch (Exception e) {
            Assert.fail(e.getMessage());
            e.printStackTrace();
        }
    }

    @DataProvider
    private Object[][] testDoPostPositiveDP() {

        Person personOne = new Person();
        personOne.setId(15l);
        personOne.setFirstName("padmavathy");
        personOne.setLastName("jayaram");
        personOne.setEmail("padma@gmail.com");
        personOne.setBirthDate(Date.valueOf("1997-05-05"));
        personOne.setAddressId(115l);

        Address addressOne = new Address();
        addressOne.setId(117l);
        addressOne.setStreet("kannagi street");
        addressOne.setCity("tirchy");
        addressOne.setPostalCode(600001);

        personOne.setAddress(addressOne);

        Person personTwo = new Person();
        personTwo.setId(5l);
        personTwo.setFirstName("kanchana");
        personTwo.setLastName("jayaram");
        personTwo.setEmail("kanchana@gmail.com");
        personTwo.setBirthDate(Date.valueOf("1997-06-23"));
        personTwo.setAddressId(116l);

        Address addressTwo = new Address();
        addressTwo.setId(116l);
        addressTwo.setStreet("kannan street");
        addressTwo.setCity("tirchy");
        addressTwo.setPostalCode(600011);

        personTwo.setAddress(addressTwo);

        return new Object[][] {
//            {"http://localhost:8080/ws/personServlet", personOne},
            {"http://localhost:8080/ws/personServlet", personTwo}
        };
    }

    @Test(dataProvider = "testDoGetPositiveReadAllDP")
    private void testDoGetPositiveReadAll(String url, List<Person> expected) throws Exception {

        String actual = new RequestHelper()
                                      .setMethod(HttpMethod.GET)
                                      .requestString(url);

        Assert.assertEquals(actual, JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testDoGetPositiveReadAllDP() {

        List<Person> persons = new ArrayList<>();
        Person personOne = new Person();
        personOne.setId(1l);
        personOne.setFirstName("kamal");
        personOne.setLastName("murali");
        personOne.setEmail("kamal@gmail.com");
        personOne.setAddressId(61l);
        personOne.setBirthDate(Date.valueOf("1997-05-27"));

        Address addressOne = new Address();
        addressOne.setId(61l);
        addressOne.setStreet("parrys street");
        addressOne.setCity("tirchy");
        addressOne.setPostalCode(600006);
        personOne.setAddress(addressOne);
        persons.add(personOne);

        Person personTwo = new Person();
        personTwo.setId(2l);
        personTwo.setFirstName("keerthi");
        personTwo.setLastName("perumal");
        personTwo.setEmail("keerthi@gmail.com");
        personTwo.setAddressId(105l);
        personTwo.setBirthDate(Date.valueOf("1998-11-13"));

        Address addressTwo = new Address();
        addressTwo.setId(105l);
        addressTwo.setStreet("ram street");
        addressTwo.setCity("chennai");
        addressTwo.setPostalCode(600001);
        personTwo.setAddress(addressTwo);

        persons.add(personTwo);

        return new Object[][] {
//            {"http://localhost:8080/ws/personServlet", personOne},
            {"http://localhost:8080/ws/personServlet?address=true", persons}
        };
    }

    @Test(dataProvider = "testDoPutNegativeDP")
    private void testDoPutNegative(String url, Person input) throws Exception {
            String actual = new RequestHelper()
                                .setMethod(HttpMethod.PUT)
                                .setInput(input)
                                .requestString(url);
            System.out.println(actual);
//            Assert.assertTrue(actual > 0, "person not created");
    }

    @DataProvider
    private Object[][] testDoPutNegativeDP() {

//        Person personOne = new Person();
//        personOne.setFirstName("padmavathy");
//        personOne.setLastName("murali");
//        personOne.setEmail("padma@gmail.com");
//        personOne.setBirthDate(Date.valueOf("1997-05-05"));
//
//        Address addressOne = new Address();
//        addressOne.setStreet("kannagi street");
//        addressOne.setCity("chennai");
//        addressOne.setPostalCode(600001);
//
//        personOne.setAddress(addressOne);

        Person personTwo = new Person();
        personTwo.setFirstName("");
        personTwo.setLastName("sivamani");
        personTwo.setEmail("kanchana@gmail.com");
        personTwo.setBirthDate(Date.valueOf("1997-06-23"));

        Address addressTwo = new Address();
        addressTwo.setStreet("kannan street");
        addressTwo.setCity("chennai");
        addressTwo.setPostalCode(600011);

        personTwo.setAddress(addressTwo);

        return new Object[][] {
//            {"http://localhost:8080/ws/personServlet", personOne},
            {"http://localhost:8080/ws/personServlet?userName=kamal@gmail.com&passWord=kamal", personTwo}
        };
    }

    @Test(dataProvider = "testDoGetNegativeDP")
    private void testDoGetNegative(String url, Person expected) throws Exception {

            String actual = new RequestHelper()
                               .setMethod(HttpMethod.GET)
                               .requestString(url);

            System.out.println(actual);
    }

    @DataProvider
    private Object[][] testDoGetNegativeDP() {

        Person personOne = new Person();
        personOne.setId(1l);
        personOne.setFirstName("murali");
        personOne.setLastName("murugan");
        personOne.setEmail("murali@gmail.com");
        personOne.setAddressId(91l);
        personOne.setBirthDate(Date.valueOf("1996-08-27"));

        Person personTwo = new Person();
        personTwo.setId(2l);
        personTwo.setFirstName("vidhyaa");
        personTwo.setLastName("masilamani");
        personTwo.setEmail("vidhyaa@gmail.com");
        personTwo.setAddressId(92l);
        personTwo.setBirthDate(Date.valueOf("1997-09-15"));
        return new Object[][] {
            {"http://localhost:8080/ws/personServlet?id=abc", personOne},
            {"http://localhost:8080/ws/personServlet?id=1000", personTwo}
        };
    }
}
