/**
 * 
 */
package com.objectfrontier.training.servlet.test;

import java.sql.Date;

import javax.servlet.http.HttpServlet;

import org.apache.http.HttpResponse;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.api.Person;
import com.objectfrontier.training.util.HttpMethod;
import com.objectfrontier.training.util.JsonUtil;
import com.objectfrontier.training.util.RequestHelper;

/**
 * @author kamalesh.murali
 * @since Nov 21, 2018
 */
public class TestAuthenticatedServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static RequestHelper helper;

    @BeforeClass
    private void setUp() throws Exception {

        helper = RequestHelper.create();
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
        HttpResponse response = helper.setUri("authenticationServlet?userName=kamal@gmail.com&passWord=kamal")
                                      .setMethod(HttpMethod.GET)
                                      .setSecured(true)
                                      .requestRaw();
        helper.setSecureDetails(response);

        System.out.println(response);
    }

    @Test
    private void testDoGetAuthenticatedPositive() throws Exception {

        Person person = helper.setUri("personServlet?id=1")
                              .setMethod(HttpMethod.GET)
                              .setSecured(true)
                              .requestObject(Person.class);
        System.out.println(person);
        Person expected = new Person();
        expected.setId(1l);
        expected.setFirstName("kamal");
        expected.setLastName("murali");
        expected.setEmail("kamal@gmail.com");
        expected.setAddressId(61l);
        expected.setBirthDate(Date.valueOf("1997-05-27"));
        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(expected));
        System.out.println(JsonUtil.toJson(person));
    }

    @Test
    private void testLogout() throws Exception {

        String response = helper.setUri("authenticationServlet")
                               .setMethod(HttpMethod.DELETE)
                               .setSecured(true)
                               .requestString();
        System.out.println(response);
    }

    @Test
    private void testAuthorizationPositivePut() throws Exception {

        Address addressOne = new Address();
        addressOne.setStreet("parrys street");
        addressOne.setCity("chennai");
        addressOne.setPostalCode(600006);

        Person personOne = new Person();
        personOne.setFirstName("murali");
        personOne.setLastName("krish");
        personOne.setEmail("muralikrish@gmail.com");
        Date date = Date.valueOf("1996-08-27"); 
        personOne.setBirthDate(date);
        personOne.setAddress(addressOne);

        long person = helper.setUri("personServlet")
                .setMethod(HttpMethod.PUT)
                .setInput(personOne)
                .setSecured(true)
                .requestObject(long.class);
        System.out.println(person);
    }

    @Test
    private void testAuthorizationPositiveDelete() throws Exception {

        long person = helper.setUri("personServlet?id=0")
                .setMethod(HttpMethod.DELETE)
                .setSecured(true)
                .requestObject(Long.class);
        System.out.println(person);
    }

    @Test
    private void testAuthorizationPositivePost() throws Exception {

        Address addressOne = new Address();
        addressOne.setId(141l);
        addressOne.setStreet("parrys street");
        addressOne.setCity("chennai");
        addressOne.setPostalCode(600006);

        Person personOne = new Person();
        personOne.setId(4l);
        personOne.setFirstName("murali");
        personOne.setLastName("kamalesh");
        personOne.setEmail("muralik@gmail.com");
        Date date = Date.valueOf("1996-08-27"); 
        personOne.setBirthDate(date);
        personOne.setAddressId(141l);
        personOne.setAddress(addressOne);

        Person person = helper.setUri("personServlet")
                .setMethod(HttpMethod.POST)
                .setInput(personOne)
                .setSecured(true)
                .requestObject(Person.class);
        System.out.println(person);
    }

    @AfterClass
    private void tearDown() {
        
    }
}
