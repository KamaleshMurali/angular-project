/**
 * 
 */
package com.objectfrontier.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.api.AppErrorCode;
import com.objectfrontier.training.api.Person;
import com.objectfrontier.training.service.AuthenticationService;
import com.objectfrontier.training.util.JsonUtil;

/**
 * @author kamalesh.murali
 * @since Nov 20, 2018
 */
public class AuthenticationServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        PrintWriter writer = response.getWriter();
        String userName = request.getParameter("userName");
        String passWord = request.getParameter("passWord");

        AuthenticationService authenticationService = new AuthenticationService();
        Person person = authenticationService.login(userName, passWord);
        HttpSession session = request.getSession();
        String id = session.getId();
        session.setAttribute("sessionId", id);
        session.setAttribute("person", person);

        response.setHeader("sessionId", id);
        response.setStatus(200);
        writer.write(JsonUtil.toJson(person));
        writer.close();
    }

    public void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {

        HttpSession session = request.getSession(false);
        PrintWriter writer = response.getWriter();
        if (session.equals(null)) {
            writer.write(JsonUtil.toJson(AppErrorCode.UN_AUTHENTICATED_USER));
        } else {
            session.invalidate();
            writer.write("Logout successfully");
        }
        writer.close();
    }
}
