/**
 *
 */
package com.objectfrontier.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Objects;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.api.AddressAbstract;
import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.servlet.ConnectionService;
import com.objectfrontier.training.api.AppErrorCode;


/**
 * @author kamalesh.murali
 * @since Sep 21, 2018
 */
public class AddressService implements AddressAbstract {

    public long create(Address address) {

        long autoIncrementedKey = 0;
        validate(address);
        try {
            String query = "INSERT INTO ADDRESS(`street`, `city`, `postal_code`) VALUES (?, ?, ?)";
            Connection connection = ConnectionService.getConnection();
            PreparedStatement insertStatement = connection.prepareStatement(query,
                                                PreparedStatement.RETURN_GENERATED_KEYS);

            insertStatement.setString(1, address.getStreet());
            insertStatement.setString(2, address.getCity()); 
            insertStatement.setInt(3, address.getPostalCode());

            int rowsAffected = insertStatement.executeUpdate();
            log("No.of.RowsInserted : %d", rowsAffected);
            ResultSet result = insertStatement.getGeneratedKeys();

            while (result.next()) {
                autoIncrementedKey =  result.getLong(1);
            }
            System.out.println("key is" + autoIncrementedKey);
            return autoIncrementedKey;
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_CREATE_ADDRESS, e);
        }
    }

    public Address update(Address address) {

        validate(address);
        if (address.getId() == null) {
            throw new AppException(AppErrorCode.INVALID_ADDRESS_ID);
        }
        try {
            String query = "UPDATE address SET street = ?, city = ?, postal_code = ? WHERE id = ?";
            Connection connection = ConnectionService.getConnection();
            PreparedStatement updateStatement = connection.prepareStatement(query);
            
            updateStatement.setString(1, address.getStreet());
            updateStatement.setString(2, address.getCity());
            updateStatement.setLong(3, address.getPostalCode());
            updateStatement.setLong(4, address.getId());
            
            int rowsAffected = updateStatement.executeUpdate();
            log("Rows updated : %d", rowsAffected);
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_UPDATE_ADDRESS, e);
        }
        return address;
    }

    public Address delete(Address address) {

        if (isEmpty(address.getId())) {
            throw new AppException(AppErrorCode.INVALID_ADDRESS_ID);
        }
        try {
            String query  = "Delete FROM address WHERE id = ?";
            Connection connection = ConnectionService.getConnection();
            PreparedStatement deleteStatement = connection.prepareStatement(query);
            deleteStatement.setLong(1, address.getId());
            
            int rowsAffected = deleteStatement.executeUpdate();
            log("Rows Deleted : %d", rowsAffected);
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_DELETE_ADDRESS, e);
        }
        return address;
    }

    public ArrayList<Address> readAll() {
        
        ArrayList<Address> records;
        try {
            String query = "SELECT id, street, city, postal_code FROM address;";
            Connection connection = ConnectionService.getConnection();
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(query);
            int columnCount = result.getMetaData().getColumnCount();
            records = new ArrayList<>(columnCount);
            while (result.next()) {
                Address address = new Address();
                address.setId(result.getLong("id"));
                address.setStreet(result.getString("street"));
                address.setCity(result.getString("city"));
                address.setPostalCode(result.getInt("postal_code"));
                records.add(address);
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_READALL_ADDRESS, e);
        }
        return records;
    }

    public Address read(long id) {

        Address record = null;
        ResultSet result = null;
        try {
            String query = "SELECT id, street, city, postal_code FROM address WHERE id = ?;";
            Connection connection = ConnectionService.getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setLong(1, id);
            result = statement.executeQuery();
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_READ_ADDRESS, e);
        }
        record = constructAddress(record, result);
        if (isEmpty(record)) {
            throw new AppException(AppErrorCode.PERSON_NOT_FOUND);
        }
        return record;
    }

    public Address constructAddress(Address record, ResultSet result) {
        try {
            while (result.next()) {
                record = new Address();
                record.setId(result.getLong("id"));
                record.setStreet(result.getString("street"));
                record.setCity(result.getString("city"));
                record.setPostalCode(result.getInt("postal_code"));
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_CONSTRUCT_ADDRESS);
        }
        return record;
    }

    private boolean isEmpty(Object value) {
        return Objects.isNull(value) || "".equals(value);
    }

    private void validate(Address address) {
        ArrayList<AppErrorCode> exceptions = new ArrayList<>();
        if (isEmpty(address.getStreet())) {
            exceptions.add(AppErrorCode.INVALID_STREET_NAME);
        }
        if (isEmpty(address.getCity())) {
            exceptions.add(AppErrorCode.INVALID_CITY_NAME);
        }
        if (isEmpty(address.getPostalCode())) {
            exceptions.add(AppErrorCode.INVALID_POSTAL_CODE);
        }
//        if (address.getPostalCode() > 100000 && address.getPostalCode() < 1000000) {
//            exceptions.add(CustomError.INVALID_POSTAL_CODE);
//        }
        if(exceptions.size() > 0) {
            throw new AppException(exceptions);
        }
    }

    public ArrayList<Address> search(String[] fields, String searchInput) {

        ArrayList<AppErrorCode> errors = new ArrayList<>();
        if (isEmpty(searchInput)) {
            errors.add(AppErrorCode.INVALID_SEARCH_INPUT);
        }
        if (fields.length == 0) {
            errors.add(AppErrorCode.INVALID_FIELD_NAME);
        }
        if (errors.size() > 0) {
            throw new AppException(errors);
        }
        ArrayList<Address> searchResults = null;
        try {
            StringBuilder sb = new StringBuilder()
                                .append("SELECT * FROM address WHERE ");
            for (String field : fields) {
                sb.append(String.format("%s LIKE ? OR ", field));
            }
            String query = sb.substring(0, sb.length() - 4);
            Connection connection = ConnectionService.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            String input = new StringBuilder()
                              .append(searchInput)
                              .append("%")
                              .toString();
            System.out.println(input);
            for (int i = 1; i <= fields.length ; i++) {
                preparedStatement.setString(i, input);
            }
            ResultSet resultSet = preparedStatement.executeQuery();
            searchResults = new ArrayList<>();
            while (resultSet.next()) {
                Address address = new Address();
                address.setId(resultSet.getLong("id"));
                address.setStreet(resultSet.getString("street"));
                address.setCity(resultSet.getString("city"));
                address.setPostalCode(resultSet.getInt("postal_code"));
                searchResults.add(address);
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_SEARCH_ADDRESS, e);
        }
        return searchResults;
    }

    private void log(String format, Object... values) {
        System.out.format(format, values);
    }

//    public static void main(String[] args) throws Exception {
//        AddressService addressService = new AddressService();
//        Address recordOne = new Address();
//        recordOne.setStreet("siva street");
//        recordOne.setCity("tirchy");
//        recordOne.setPostalCode(600555);
//        Connection connection = ConnectionManager.createConnection();
//        long id = addressService.create(initConnection, recordOne);
//        System.out.println(id);
//        String[] fields = {"street", "city"};
//        String searchInput = "ch";
//        ArrayList<Address> addresses = addressService.search(connection, fields, searchInput);
//        ArrayList<Address> expectedResult = new ArrayList<>();
//        Address address = new Address();
//        address.setId(2l);
//        address.setStreet("karan street");
//        address.setCity("chennai");
//        address.setPostalCode(605002);
//        expectedResult.add(address);
//        Address anotherAddress = new Address();
//        anotherAddress.setStreet("kanchi street");
//        anotherAddress.setCity("chennai");
//        anotherAddress.setPostalCode(652106);
//        expectedResult.add(anotherAddress);
//        boolean result = expectedResult.containsAll(addresses);
//        System.out.println(addresses.size());
//        System.out.println(addresses);
//        System.out.println(result);
//        Address addressOne = addressService.read(connection, address);
//    }
}
