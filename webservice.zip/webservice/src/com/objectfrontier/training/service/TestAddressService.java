/**
 *
 */
package com.objectfrontier.training.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.api.AppErrorCode;
import com.objectfrontier.training.util.JsonUtil;

/**
 * @author kamalesh.murali
 * @since Sep 22, 2018
 */
public class TestAddressService {

    @BeforeClass
    private void setup() {
    }

    @Test(priority = 1, dataProvider = "testPositiveCreateDP")
    private void testPositiveCreate(Address address) throws Exception {
        Connection newConnection = null;
        AddressService addressService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            long actualResult = addressService.create(newConnection, address); 
//            System.out.println(actualResult);
            Assert.assertTrue(actualResult > 0);
            newConnection.commit();
        } catch (AppException e) {
            newConnection.rollback();
            Assert.fail(e.getMessage());
        } finally {
            newConnection.close();
            addressService = null;
        }
    } 

    @DataProvider
    private Object[][] testPositiveCreateDP() {
        Address recordOne = new Address();
        recordOne.setStreet("siva street");
        recordOne.setCity("tirchy");
        recordOne.setPostalCode(600555);

        Address recordTwo = new Address();
        recordTwo.setStreet("raja street");
        recordTwo.setCity("pondicherry");
        recordTwo.setPostalCode(605201);

        Address recordThree = new Address();
        recordThree.setStreet("rajaji street");
        recordThree.setCity("chennai");
        recordThree.setPostalCode(605021);

        return new Object[][] {
            {recordOne},
            {recordTwo},
            {recordThree}
        };
    }

    @Test(priority = 2, dataProvider = "testNegativeCreateDP")
    private void testNegativeCreate(Address address, ArrayList<AppErrorCode> expectedExceptions) throws Exception {
        Connection newConnection = null;
        AddressService addressService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            addressService.create(newConnection, address);
            Assert.fail("expected an exception");
        } catch (AppException exceptions) {
            Assert.assertEquals(exceptions.errorCodes, expectedExceptions);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testNegativeCreateDP() {
        Address address = new Address();
        address.setStreet("");
        address.setCity("");
        address.setPostalCode(null);
        ArrayList<AppErrorCode> expectedExceptions = new ArrayList<>();
        expectedExceptions.add(AppErrorCode.INVALID_STREET_NAME);
        expectedExceptions.add(AppErrorCode.INVALID_CITY_NAME);
        expectedExceptions.add(AppErrorCode.INVALID_POSTAL_CODE);
        return new Object[][] {
            {address, expectedExceptions}
        };
    }

    @Test(priority = 3, dataProvider = "testNegativeCreate_EmptyStreetDP")
    private void testNegativeCreate_EmptyStreet(Address address, ArrayList<AppErrorCode> expectedExceptions) throws Exception {
        Connection newConnection = null;
        AddressService addressService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            addressService.create(newConnection, address);
            Assert.fail("expected an exception");
        } catch (AppException exceptions) {
//            System.out.println(exceptions.errorCodes);
//            System.out.println(expectedExceptions);
            Assert.assertEquals(exceptions.errorCodes, expectedExceptions);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testNegativeCreate_EmptyStreetDP() {
        Address address = new Address();
        address.setStreet("");
        address.setCity("chennai");
        address.setPostalCode(600001);
        ArrayList<AppErrorCode> expectedExceptions = new ArrayList<>();
        expectedExceptions.add(AppErrorCode.INVALID_STREET_NAME);
        return new Object[][] {
            {address, expectedExceptions}
        };
    }

    @Test(priority = 4, dataProvider = "testNegativeCreate_EmptyCityDP")
    private void testNegativeCreate_EmptyCity(Address address, ArrayList<AppErrorCode> expectedExceptions) throws Exception {
        Connection newConnection = null;
        AddressService addressService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            addressService.create(newConnection, address);
            Assert.fail("expected an exception");
        } catch (AppException exceptions) {
            Assert.assertEquals(exceptions.errorCodes, expectedExceptions);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testNegativeCreate_EmptyCityDP() {
        Address address = new Address();
        address.setStreet("sivam street");
        address.setCity("");
        address.setPostalCode(600001);
        ArrayList<AppErrorCode> expectedExceptions = new ArrayList<>();
        expectedExceptions.add(AppErrorCode.INVALID_CITY_NAME);
        return new Object[][] {
            {address, expectedExceptions}
        };
    }

    @Test(priority = 5, dataProvider = "testNegativeCreate_EmptyPostalCodeDP")
    private void testNegativeCreate_EmptyPostalCode(Address address, ArrayList<AppException> expectedExceptions) throws Exception {
        Connection newConnection = null;
        AddressService addressService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            addressService.create(newConnection, address);
            Assert.fail("expected an exception");
        } catch (AppException exceptions) {
            Assert.assertEquals(exceptions.errorCodes, expectedExceptions);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testNegativeCreate_EmptyPostalCodeDP() {
        Address address = new Address();
        address.setStreet("sivam street");
        address.setCity("chennai");
        address.setPostalCode(null);
        ArrayList<AppErrorCode> expectedExceptions = new ArrayList<>();
        expectedExceptions.add(AppErrorCode.INVALID_POSTAL_CODE);
        return new Object[][] {
            {address, expectedExceptions}
        };
    }

    @Test(priority = 6, dataProvider = "testCreate_negativeDP")
    private void createRecord_negative(Address address
                                     , ArrayList<AppErrorCode> expectedExceptions) throws Exception {
        Connection newConnection = null;
        AddressService addressService = null;
        try{
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            addressService.create(newConnection, address);
            Assert.fail("Expected an exception");
            newConnection.rollback();
        } catch (AppException error) {
            Assert.assertEquals(error.errorCodes, expectedExceptions);
            //Assert.expectThrows(throwableClass, runnable)
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() {
        Address addressRecordOne = new Address();
        addressRecordOne.setStreet("");
        addressRecordOne.setCity("");
        addressRecordOne.setPostalCode(null);
        
        ArrayList<AppErrorCode> expectedExceptions = new ArrayList<>();
        expectedExceptions.add(AppErrorCode.INVALID_STREET_NAME);
        expectedExceptions.add(AppErrorCode.INVALID_CITY_NAME);
        expectedExceptions.add(AppErrorCode.INVALID_POSTAL_CODE);
        
        return new Object[][] { {addressRecordOne, expectedExceptions}
        //  , {addressRecordTwo}
        };
    }

    @Test(priority = 7, dataProvider = "testPositiveRecordUpdateDP")
    private void testPositiveRecordUpdate(Address address) throws Exception {
        AddressService addressService = null;
        Connection newConnection = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            Address actualResult = addressService.update(newConnection, address);
            
            Assert.assertEquals(actualResult.toString(), address.toString());
            newConnection.commit();
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testPositiveRecordUpdateDP() {
        Address recordOne = new Address();
        recordOne.setId(new Long(3));
        recordOne.setStreet("raja street");
        recordOne.setCity("pondicherry");
        recordOne.setPostalCode(605021);

        Address recordTwo = new Address();
        recordTwo.setId(new Long(2));
        recordTwo.setStreet("rani street");
        recordTwo.setCity("tirunelveli");
        recordTwo.setPostalCode(605021);

        return new Object[][] {
            {recordOne}
            , {recordTwo}
        };
    }

    @Test(priority = 8)
    private void testNegativeUpdate_id() throws Exception {
        AddressService addressService = null;
        Connection newConnection = null;
        try {
            newConnection = ConnectionManager.createConnection();
            Address newAddress = new Address();
            newAddress.setId(null);
            newAddress.setStreet("mani street");
            newAddress.setCity("chennai");
            newAddress.setPostalCode(600001);
            addressService = new AddressService();
            addressService.update(newConnection, newAddress);
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCode, AppErrorCode.INVALID_ADDRESS_ID);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @Test(priority = 9, dataProvider = "testNegativeRecordUpdateDP")
    private void testNegativeUpdate(Address address, ArrayList<AppErrorCode> errors) throws Exception {
        AddressService addressService = null;
        Connection newConnection = null;
        try {
            newConnection = ConnectionManager.createConnection();

            addressService = new AddressService();
            addressService.update(newConnection, address);
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCodes, errors);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testNegativeRecordUpdateDP() {
        Address address = new Address();
        address.setId(2l);
        address.setStreet("");
        address.setCity("");
        address.setPostalCode(null);
    
        ArrayList<AppErrorCode> expectedErrors = new ArrayList<>();
        expectedErrors.add(AppErrorCode.INVALID_STREET_NAME);
        expectedErrors.add(AppErrorCode.INVALID_CITY_NAME);
        expectedErrors.add(AppErrorCode.INVALID_POSTAL_CODE);
    
        return new Object[][] {
            {address, expectedErrors}
        };
    }

    @Test(priority = 10)
    private void testNegativeUpdate_Street() throws Exception {
        AddressService addressService = null;
        Connection newConnection = null;
        ArrayList<AppErrorCode> expectedError = null;
        try {
            newConnection = ConnectionManager.createConnection();
            Address newAddress = new Address();
            newAddress.setId(2l);
            newAddress.setStreet("");
            newAddress.setCity("chennai");
            newAddress.setPostalCode(600001);
            expectedError = new ArrayList<>();
            expectedError.add(AppErrorCode.INVALID_STREET_NAME);
            addressService = new AddressService();
            addressService.update(newConnection, newAddress);
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCodes, expectedError);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @Test(priority = 11)
    private void testNegativeUpdate_city() throws Exception {
        AddressService addressService = null;
        Connection newConnection = null;
        ArrayList<AppErrorCode> expectedError = null;
        try {
            newConnection = ConnectionManager.createConnection();
            Address newAddress = new Address();
            newAddress.setId(2l);
            newAddress.setStreet("mani street");
            newAddress.setCity("");
            newAddress.setPostalCode(600001);
            expectedError = new ArrayList<>();
            expectedError.add(AppErrorCode.INVALID_CITY_NAME);
            addressService = new AddressService();
            addressService.update(newConnection, newAddress);
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCodes, expectedError);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @Test(priority = 12)
    private void testNegativeUpdate_postalCode() throws Exception {
        AddressService addressService = null;
        Connection newConnection = null;
        ArrayList<AppErrorCode> expectedError = null;
        try {
            newConnection = ConnectionManager.createConnection();
            Address newAddress = new Address();
            newAddress.setId(2l);
            newAddress.setStreet("mani street");
            newAddress.setCity("chennai");
            newAddress.setPostalCode(null);
            expectedError = new ArrayList<>();
            expectedError.add(AppErrorCode.INVALID_POSTAL_CODE);
            addressService = new AddressService();
            addressService.update(newConnection, newAddress);
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCodes, expectedError);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @Test(priority = 13, dataProvider = "testPositiveDeleteRecordDP")
    private void testPositiveDeleteRecord(Address address) throws Exception {
        AddressService addressService = null;
        Connection newConnection = null;
        try {
            newConnection = ConnectionManager.createConnection();
            Address expectedResult = address;
            addressService = new AddressService();
            Address actualResult = addressService.delete(newConnection, address);
            newConnection.commit();
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testPositiveDeleteRecordDP() {
        Address address = new Address();
        address.setId(3l);
        address.setStreet("rajaji street");
        address.setCity("chennai");
        address.setPostalCode(605021);

        return new Object[][] {
           {address}
        };
    }

    @Test(priority = 14)
    private void testNegativeDelete() throws Exception {
        AddressService addressService = null;
        Connection newConnection = null;
        try {
            newConnection = ConnectionManager.createConnection();
            Address address = new Address();
            address.setId(null);
            addressService = new AddressService();
            addressService.delete(newConnection, address);
            Assert.fail("expected an exception");
        } catch(AppException e) {
            Assert.assertEquals(e.errorCode, AppErrorCode.INVALID_ADDRESS_ID);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @Test(priority = 15, dataProvider = "testPositiveReadDP")
    private void testPositiveRead(long address) throws Exception {
        Connection newConnection = null;
        AddressService addressService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            Address actualResult = addressService.read(newConnection, address);
            long expectedResult = address;
            Assert.assertEquals(actualResult.toString(), expectedResult);
        } catch (AppException e) {
            Assert.fail("AppException :", e); 
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testPositiveReadDP() {
        Address address = new Address();
        address.setId(2l);
        address.setStreet("rani street");
        address.setCity("tirunelveli");
        address.setPostalCode(605021);
        return new Object[][] {
            {address}
        };
    }

    @Test(priority = 16, dataProvider = "testNegativeRead_idDP")
    private void testNegativeRead_id(Address address, long id) throws Exception {
        Connection newConnection = null;
        AddressService addressService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
//            long id = address.getId();
            addressService.read(newConnection, id);
        } catch (AppException e) {
            Assert.assertEquals(e.errorCode, AppErrorCode.INVALID_ADDRESS_ID);
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testNegativeRead_idDP() {
        Address address = new Address();
        address.setId(1l);
        address.setStreet("rani street");
        address.setCity("tirunelveli");
        address.setPostalCode(605021);
        return new Object[][] {
            {address, 1l}
        };
    }
    @Test(priority = 17, dataProvider = "testPositiveReadAllRecord")
    private void testPositiveReadAll(ArrayList<Address> records) throws Exception {
        Connection newConnection = null;
        AddressService addressService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            ArrayList<Address> expectedResult = records;
            ArrayList<Address> actualResult = addressService.readAll(newConnection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch(AppException e) {
            System.out.println(e.getMessage());
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testPositiveReadAllRecord() {
        ArrayList<Address> records = new ArrayList<>(2); 
        Address recordOne = new Address();
        recordOne.setId(1l);
        recordOne.setStreet("siva street");
        recordOne.setCity("tirchy");
        recordOne.setPostalCode(600555);
        records.add(recordOne);
        Address recordTwo = new Address();
        recordTwo.setId(2l);
        recordTwo.setStreet("rani street");
        recordTwo.setCity("tirunelveli");
        recordTwo.setPostalCode(605021);
        records.add(recordTwo);
        return new Object[][] {
            {records}
        };
    }

    @Test(dataProvider = "testSearchPositive_WithMultipleFieldsDP")
    private void testSearchPositive_WithMultipleFields(ArrayList<Address> expectedResult, String[] fields, String searchInput) throws Exception{
        Connection connection = null;
        AddressService addressService = null;
        try {
            connection = ConnectionManager.createConnection();
            addressService = new AddressService();
            ArrayList<Address> actualResult = addressService.search(connection, fields, searchInput);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch(AppException appException) {
            Assert.fail("SQL_EXCEPTION", appException.getCause());
        } finally {
            connection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testSearchPositive_WithMultipleFieldsDP() {
        String[] fields = {"street", "city"};
        String searchInput = "ch";
        ArrayList<Address> expectedResult = new ArrayList<>();
        Address address = new Address();
        address.setStreet("karan street");
        address.setCity("chennai");
        address.setPostalCode(605002);
        expectedResult.add(address);
        Address anotherAddress = new Address();
        anotherAddress.setStreet("kanchi street");
        anotherAddress.setCity("chennai");
        anotherAddress.setPostalCode(652106);
        expectedResult.add(anotherAddress);

        return new Object[][] {
            {expectedResult, fields, searchInput}
        };
    }

    @Test(dataProvider = "testSearchPositive_WithSingleFieldsDP")
    private void testSearchPositive_WithSingleField(ArrayList<Address> expectedResult, String[] fields, String searchInput) throws Exception{
        Connection connection = null;
        AddressService addressService = null;
        try {
            connection = ConnectionManager.createConnection();
            addressService = new AddressService();
            ArrayList<Address> actualResult = addressService.search(connection, fields, searchInput);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch(AppException appException) {
            Assert.fail("SQL_EXCEPTION", appException.getCause());
        } finally {
            connection.close();
            addressService = null;
        }
    }

    @DataProvider
    private Object[][] testSearchPositive_WithSingleFieldsDP() {
        String[] fields = {"city"};
        String searchInput = "ch";
        ArrayList<Address> expectedResult = new ArrayList<>();
        Address address = new Address();
        address.setStreet("karan street");
        address.setCity("chennai");
        address.setPostalCode(605002);
        expectedResult.add(address);
        Address anotherAddress = new Address();
        anotherAddress.setStreet("kanchi street");
        anotherAddress.setCity("chennai");
        anotherAddress.setPostalCode(652106);
        expectedResult.add(anotherAddress);

        return new Object[][] {
            {expectedResult, fields, searchInput}
        };
    }
    @Test
    private void testSearchNegative() throws Exception{
        Connection connection = null;
        AddressService addressService = null;
        ArrayList<AppErrorCode> expectedErrors = null;
        try {
            String[] fields = {};
            String searchInput = "";
            expectedErrors = new ArrayList<>();
            expectedErrors.add(AppErrorCode.INVALID_SEARCH_INPUT);
            expectedErrors.add(AppErrorCode.INVALID_FIELD_NAME);
            connection = ConnectionManager.createConnection();
            addressService = new AddressService();
            addressService.search(connection, fields, searchInput);
            Assert.fail("expected an exception");
        } catch(AppException appException) {
            Assert.assertEquals(expectedErrors, appException.errorCodes);
        } finally {
            connection.close();
            addressService = null;
        }
    }

    @Test
    private void testSearchNegative_WithNull() throws Exception{
        Connection connection = null;
        AddressService addressService = null;
        ArrayList<AppErrorCode> expectedErrors = null;
        try {
            String[] fields = {};
            String searchInput = null;
            expectedErrors = new ArrayList<>();
            expectedErrors.add(AppErrorCode.INVALID_SEARCH_INPUT);
            expectedErrors.add(AppErrorCode.INVALID_FIELD_NAME);
            connection = ConnectionManager.createConnection();
            addressService = new AddressService();
            addressService.search(connection, fields, searchInput);
            Assert.fail("expected an exception");
        } catch(AppException appException) {
            Assert.assertEquals(expectedErrors, appException.errorCodes);
        } finally {
            connection.close();
            addressService = null;
        }
    }
    
    @Test(dataProvider = "test")
    private void testPositiveCreateCsv(ArrayList<Address> addresses) throws Exception{
        Connection newConnection = null;
        AddressService addressService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            addressService = new AddressService();
            for (Address address : addresses) {
                long actualResult = addressService.create(newConnection, address); 
                Assert.assertTrue(actualResult > 0);
                newConnection.commit();
            }
        } catch (AppException e) {
            newConnection.rollback();
            Assert.fail(e.getMessage());
        } finally {
            newConnection.close();
            addressService = null;
        }
    }

    @DataProvider(name = "test")
    private Object[][] testPositiveCreateCsv() throws IOException {

        InputStream file = ConnectionManager.class.getClassLoader().getResourceAsStream("data.csv");
        BufferedReader reader = new BufferedReader(new InputStreamReader(file));
        List<String> jsonLines = reader.lines().collect(Collectors.toList());

        ArrayList<Address> addresses = null;
        addresses = new ArrayList<>();
        Address address;
        for (String jsonLine : jsonLines) {
            String addressJson = String.join("", jsonLine);
            String[] data = addressJson.split(",");
            address = new Address();
            address.setStreet(data[0]);
            address.setCity(data[1]);
            address.setPostalCode(Integer.parseInt(data[2]));
            addresses.add(address);
        }
        reader.close();
        return new Object[][] {
            {addresses}
        };
    }
    
    
    
    
    @AfterClass
    private void endClass() {
    }
}
