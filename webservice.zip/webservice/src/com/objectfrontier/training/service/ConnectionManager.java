/**
 * 
 */
package com.objectfrontier.training.service;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.api.AppErrorCode;

/**
 * @author kamalesh.murali
 * @since Sep 28, 2018
 */
public class ConnectionManager {

    public static Properties getPropertiesFile() {

        Properties properties = new Properties();
        InputStream file = ConnectionManager.class.getClassLoader().getResourceAsStream("jdbc.properties");
        try {
            properties.load(file);
            file.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return properties;
    }

    public static Connection createConnection() {

        Properties jdbcProperties = getPropertiesFile();

        String connectionString = new StringBuilder()
                                  .append(jdbcProperties.getProperty("protocol")) 
                                  .append(jdbcProperties.getProperty("host"))
                                  .append(jdbcProperties.getProperty("dbName"))
                                  .append(jdbcProperties.getProperty("sslConnection"))
                                  .append(jdbcProperties.getProperty("user"))
                                  .append(jdbcProperties.getProperty("password"))
                                  .toString();

        Connection connection = null;
        try {
            connection = DriverManager.getConnection(connectionString);
            connection.setAutoCommit(false);
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_CREATE_CONNECTION, e);
        }
        return connection;
    }

    public static void releaseConnection(Connection connection, boolean doCommit) {
        try {
            if (doCommit) {
                connection.commit();
            } else {
                connection.rollback();
            }
            connection.close();
        } catch(Exception e) {
            throw new AppException(AppErrorCode.ERROR_RELEASE_CONNECTION, e);
        }
    }

    public static void main(String[] args) throws Exception {
        ConnectionManager.createConnection();
    }
 }
