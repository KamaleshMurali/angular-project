/**
 * 
 */
package com.objectfrontier.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Objects;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.api.AppErrorCode;
import com.objectfrontier.training.api.Person;
import com.objectfrontier.training.api.PersonAbstract;
import com.objectfrontier.training.servlet.ConnectionService;

/**
 * @author kamalesh.murali
 * @since Sep 25, 2018
 */
public class PersonService implements PersonAbstract {

    public long create(Person person) {

        long key = 0;
        boolean isValidated = validate(person, false);
        try {

            if (isValidated) {
                AddressService addressService = new AddressService();
                Address address = person.getAddress();
                long addressId = addressService.create(address);
                
                String query = new StringBuilder("INSERT INTO PERSON(`first_name`")
                                         .append(", `last_name`                  ")
                                         .append(", `email`                      ")
                                         .append(", `address_id`                 ")
                                         .append(", `birth_date`                 ")
                                         .append(", `password`                   ")
                                         .append(", `is_admin`)                  ")
                                         .append(" VALUES (?, ?, ?, ?, ?, ?, ?); ")
                                         .toString();
                Connection connection = ConnectionService.getConnection();
                PreparedStatement statement = connection.prepareStatement(query,
                                              PreparedStatement.RETURN_GENERATED_KEYS);
                
                statement.setString(1, person.getFirstName());
                statement.setString(2, person.getLastName());
                statement.setString(3, person.getEmail());
                statement.setLong(4, addressId);
                statement.setDate(5, person.getBirthDate());
                statement.setString(6, person.getPassword());
                statement.setBoolean(7, person.isAdmin());

                statement.executeUpdate();
                ResultSet keyGenerated = statement.getGeneratedKeys();
                while (keyGenerated.next()) {
                    key = keyGenerated.getLong(1);
                }
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_CREATE_PERSON, e);
        }
        return key;
    }

    public Person update(Person person) {

        if (isEmpty(person.getId())) {
            throw new AppException(AppErrorCode.INVALID_PERSON_ID);
        }
        boolean isValidated = validate(person, true);
        try {
            if (isValidated) {
                AddressService addressService = new AddressService();

//                Address address = person.getAddress();
////                address.setId(person.getAddressId());
//                Address updatedAddress = addressService.update(address);
//                person.setAddress(updatedAddress);

                String query = new StringBuilder("UPDATE person SET first_name = ?")
                                         .append(", last_name = ?, email = ?      ")
//                                         .append(", address_id = ?, birth_date = ?")
                                         .append(", birth_date = ?")
                                         .append(" WHERE id = ?;                  ")
                                         .toString();
                Connection connection = ConnectionService.getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, person.getFirstName());
                statement.setString(2, person.getLastName());
                statement.setString(3, person.getEmail());
//                statement.setLong(4, person.getAddressId());
                statement.setDate(4, person.getBirthDate());
                statement.setLong(5, person.getId());

                statement.executeUpdate();
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_UPDATE_PERSON, e);
        }
        return person;
    }

    public long delete(long id) {

        if (id < 0) {
            throw new AppException(AppErrorCode.INVALID_PERSON_ID);
        }
        try {
            Person record = read(false, id);
//            long addressId = record.getAddressId();
//            Address address = new Address();
//            address.setId(addressId);
            String query  = "Delete FROM person WHERE id = ?";
            Connection connection = ConnectionService.getConnection();
            PreparedStatement deleteStatement = connection.prepareStatement(query);
            deleteStatement.setLong(1, id);
            deleteStatement.executeUpdate();

//            AddressService addressService = new AddressService();
//            addressService.delete(address);
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_DELETE_PERSON, e);
        }
        return id;
    }

    public Person read(boolean includeAddress, long id) {

        if (id > 0) {
            if (includeAddress) {
                return readWithAddress(id);
            } else {
                return readWithoutAddress(id);
            }
        }
        throw new AppException(AppErrorCode.INVALID_PERSON_ID);
    }

    public Person readWithAddress(long id) {

        Person person;
        try {
            String readQuery = new StringBuilder("SELECT id    ")
                                         .append(", first_name ")
                                         .append(", last_name  ")
                                         .append(", email      ")
                                         .append(", birth_date ")
                                         .append(", address_id ")
//                                       .append(", created_date")
                                         .append(", is_admin   ")
                                         .append(" FROM person ")
                                         .append(" WHERE id = ?")
                                         .toString();
            Connection connection = ConnectionService.getConnection();
            PreparedStatement statement = connection.prepareStatement(readQuery);
            statement.setLong(1, id);
            ResultSet result = statement.executeQuery();
            person = null;
            if (result.next()) {
                long addressId = result.getLong("address_id");
                person = new Person();
                person.setId(result.getLong("id"));
                person.setFirstName(result.getString("first_name"));
                person.setLastName(result.getString("last_name"));
                person.setEmail(result.getString("email"));
                person.setBirthDate(result.getDate("birth_date"));
                person.setAddressId(result.getLong("address_id"));
                person.setAdmin(result.getBoolean("is_admin"));
                Address address = new Address();
                address.setId(result.getLong("address_id"));

                AddressService addressService = new AddressService();
                Address personAddress = addressService.read(addressId);

                person.setAddress(personAddress);
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_READ_PERSON_WITH_ADDRESS, e);
        }
        if (isEmpty(person)) {
            throw new AppException(AppErrorCode.PERSON_NOT_FOUND);
        }
        return person;
    }

    public Person readWithoutAddress(long id) {

        Person person;
        try {
            String query = new StringBuilder("SELECT id, first_name,    ")
                                     .append(" last_name, email,        ")
                                     .append(" address_id, birth_date,  ")
                                     .append(" is_admin                 ")
                                     .append(" FROM person WHERE id = ?;")
                                     .toString();
            Connection connection = ConnectionService.getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setLong(1, id);
            ResultSet result = statement.executeQuery();
            person = null;
            while (result.next()) {
                person = new Person();
                person.setId(result.getLong("id"));
                person.setFirstName(result.getString("first_name"));
                person.setLastName(result.getString("last_name"));
                person.setEmail(result.getString("email"));
                person.setAddressId(result.getLong("address_id"));
                person.setBirthDate(result.getDate("birth_date"));
                person.setAdmin(result.getBoolean("is_admin"));
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_READ_PERSON, e);
        } 
        if (isEmpty(person)) {
            throw new AppException(AppErrorCode.PERSON_NOT_FOUND);
        }
        return person;
    }

    public ArrayList<Person> readAll(boolean includeAddress) {

        if (includeAddress) {
             return readAllWithAddress();
        } else {
             return readAllWithoutAddress();
        }
    }

    public ArrayList<Person> readAllWithAddress() {

        ArrayList<Person> persons;
        try {
            String readQuery = new StringBuilder("SELECT id   ")
                                         .append(", first_name")
                                         .append(", last_name ")
                                         .append(", email     ")
                                         .append(", birth_date")
                                         .append(", address_id")
                                         .append(", is_admin  ")
                                         .append(" FROM person")
                                         .toString();

            Connection connection = ConnectionService.getConnection();
            PreparedStatement statement = connection.prepareStatement(readQuery);
            ResultSet result = statement.executeQuery();
            int columnCount = result.getMetaData().getColumnCount();
            AddressService addressService = new AddressService();
            ArrayList<Address> addresses = addressService.readAll();
            persons = new ArrayList<>(columnCount);
            while (result.next()) {
                Person person = new Person();
                person.setId(result.getLong("id"));
                person.setFirstName(result.getString("first_name"));
                person.setLastName(result.getString("last_name"));
                person.setEmail(result.getString("email"));
                person.setBirthDate(result.getDate("birth_date"));
                person.setAddressId(result.getLong("address_id"));
                person.setAdmin(result.getBoolean("is_admin"));

                addresses.stream()
                         .filter(address -> address.getId() == person.getAddressId())
                         .forEach(address -> person.setAddress(address));
                persons.add(person);
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_READALL_PERSON_WITH_ADDRESS, e);
        }
        return persons;
    }

    public ArrayList<Person> readAllWithoutAddress() {

        ArrayList<Person> records;
        try {
            String query = new StringBuilder("SELECT id, first_name, ")
                                     .append(" last_name, email,     ")
                                     .append(" address_id, birth_date")
                                     .append(", is_admin             ")
                                     .append(" FROM person;          ")
                                     .toString();
            Connection connection = ConnectionService .getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet result = statement.executeQuery();
            Person person = null;
            records = new ArrayList<>();
            while (result.next()) {
                person = new Person();
                person.setId(result.getLong("id"));
                person.setFirstName(result.getString("first_name"));
                person.setLastName(result.getString("last_name"));
                person.setEmail(result.getString("email"));
                person.setAddressId(result.getLong("address_id"));
                person.setBirthDate(result.getDate("birth_date"));
                person.setAdmin(result.getBoolean("is_admin"));

                records.add(person);
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_READALL_PERSON, e);
        }
        return records;
    }

    private boolean isEmpty(Object value) {
        return Objects.isNull(value) || "".equals(value);
    }

    private boolean validate(Person person, boolean forUpdate) {
        ArrayList<AppErrorCode> exceptions = new ArrayList<>();
        if (isEmpty(person.getFirstName())) {
            exceptions.add(AppErrorCode.INVALID_FIRST_NAME);
        }

        if (isEmpty(person.getLastName())) {
            exceptions.add(AppErrorCode.INVALID_LAST_NAME);
        }

        if (!isEmpty(person.getFirstName()) && !isEmpty(person.getLastName())) {

            boolean isDuplicateNames = validateDuplicateNames(person, forUpdate);
            
            if (isDuplicateNames) {
                exceptions.add(AppErrorCode.DUPLICATED_FIRST_NAME_AND_LAST_NAME);
            }
        }

        if (isEmpty(person.getBirthDate())) {
            exceptions.add(AppErrorCode.INVALID_BIRTH_DATE);
        }

        if (isEmpty(person.getEmail())) {
            exceptions.add(AppErrorCode.INVALID_EMAIL_ADDRESS);
        } else {
            boolean isDuplicateEmail = validateDuplicateEmail(person, forUpdate);

            if (isDuplicateEmail) {
                exceptions.add(AppErrorCode.DUPLICATE_EMAIL_ID);
            }
        }

        if(exceptions.size() > 0) {
            throw new AppException(exceptions);
        }
        return true;
    }

    private boolean validateDuplicateEmail(Person person, boolean forUpdate) {

        int count;
        try {
            if (forUpdate) {
                String query = new StringBuilder()
                                  .append("SELECT COUNT(email) FROM person ")
                                  .append("WHERE email = ? AND id != ?;    ")
                                  .toString();
                Connection connection = ConnectionService.getConnection();
                PreparedStatement prepareStatement = connection.prepareStatement(query);
                prepareStatement.setString(1, person.getEmail());
                prepareStatement.setLong(2, person.getId());
                ResultSet result = prepareStatement.executeQuery();
                count = 0;
                while (result.next()) {
                    count = result.getInt(1);
                    System.out.println("emails : " + count);
                }
                return count > 0 ? true : false;
            } else {
                String query = new StringBuilder()
                                  .append("SELECT COUNT(email) FROM person ")
                                  .append("WHERE email = ?;                ")
                                  .toString();
                Connection connection = ConnectionService.getConnection();
                PreparedStatement prepareStatement = connection.prepareStatement(query);
                prepareStatement.setString(1, person.getEmail());
                ResultSet result = prepareStatement.executeQuery();
                count = 0;
                while (result.next()) {
                    count = result.getInt(1);
                    System.out.println("emails : " + count);
                }
                return count > 0 ? true : false;
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_DUPLICATE_EMAIL_ID, e);
        }
    }

    private boolean validateDuplicateNames(Person person, boolean forUpdate) {

        int count;
        try {
            if (forUpdate) {
                String query = new StringBuilder()
                                  .append("SELECT COUNT(*) FROM person            ")
                                  .append("WHERE first_name = ? AND last_name = ? ")
                                  .append("AND id != ?                            ")
                                  .toString();
                Connection connection = ConnectionService.getConnection();
                PreparedStatement prepareStatement = connection.prepareStatement(query);
                prepareStatement.setString(1, person.getFirstName());
                prepareStatement.setString(2, person.getLastName());
                prepareStatement.setLong(3, person.getId());
                ResultSet result = prepareStatement.executeQuery();
                count = 0;
                while (result.next()) {
                    count = result.getInt(1);
                    System.out.println("names : " + count);
                }
                return count > 0 ? true : false;
            } else {
                String query = new StringBuilder()
                                  .append("SELECT COUNT(*) FROM person            ")
                                  .append("WHERE first_name = ? AND last_name = ?;")
                                  .toString();
                Connection connection = ConnectionService.getConnection();
                PreparedStatement prepareStatement = connection.prepareStatement(query);
                prepareStatement.setString(1, person.getFirstName());
                prepareStatement.setString(2, person.getLastName());
                ResultSet result = prepareStatement.executeQuery();
                count = 0;
                while (result.next()) {
                    count = result.getInt(1);
                    System.out.println("names : " + count);
                }
                return count > 0 ? true : false;
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.ERROR_DUPLICATE_NAME, e);
        }
    }
}
