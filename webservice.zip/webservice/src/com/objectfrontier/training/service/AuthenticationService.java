/**
 * 
 */
package com.objectfrontier.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Objects;

import com.objectfrontier.training.api.AppErrorCode;
import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.api.Person;
import com.objectfrontier.training.servlet.ConnectionService;

/**
 * @author kamalesh.murali
 * @since Nov 19, 2018
 */
public class AuthenticationService {

    public Person login(String userName, String passWord) {

        ArrayList<AppErrorCode> errors = new ArrayList<>();
        if (isEmpty(userName)) {
            errors.add(AppErrorCode.INVALID_USER_NAME);
        }
        if (isEmpty(passWord)) {
            errors.add(AppErrorCode.INVALID_PASSWORD);
        }
        if (errors.size() > 0) {
            throw new AppException(errors);
        }

        String query = "SELECT * FROM person WHERE email = ? AND password = ?";

        Person person = null;
        Connection connection = ConnectionService.getConnection(); 
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, userName);
            ps.setString(2, passWord);

            ResultSet result = ps.executeQuery();

            if (result.next()) {
                person = new Person();
                person.setFirstName(result.getString("first_name"));
                person.setLastName(result.getString("last_name"));
                person.setEmail(result.getString("email"));
                person.setAdmin(result.getBoolean("is_admin"));
            }
        } catch (Exception e) {
            throw new AppException(AppErrorCode.LOGIN_ERROR, e);
        }
        if (isEmpty(person)) {
            throw new AppException(AppErrorCode.AUTHENTICATION_FAILED);
        }
        return person;
    }

    private boolean isEmpty(Object value) {
        return Objects.isNull(value) || "".equals(value);
    }
}
