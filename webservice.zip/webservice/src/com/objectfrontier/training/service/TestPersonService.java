package com.objectfrontier.training.service;

import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.api.Address;
import com.objectfrontier.training.api.AppException;
import com.objectfrontier.training.api.AppErrorCode;
import com.objectfrontier.training.api.Person;

/**
 * 
 */

/**
 * @author kamalesh.murali
 * @since Sep 28, 2018
 */
public class TestPersonService {

    @BeforeClass
    public void setup() {
    }

    @Test(dataProvider = "testCreatePositiveDP")
    private void testCreatePositive(Person person) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection(); 
            personService = new PersonService();
            long actualResult = personService.create(newConnection, person);
            Assert.assertTrue(actualResult > 0);
            newConnection.commit(); 
        } catch (AppException e) {
            newConnection.rollback();
            System.out.println(e.getCause());
            Assert.fail("Errors : " + e.errorCodes);
        } finally { 
            newConnection.close();
        }
    }

    @DataProvider
    private Object[][] testCreatePositiveDP() {
        Address addressOne = new Address();
        addressOne.setStreet("parrys street");
        addressOne.setCity("chennai");
        addressOne.setPostalCode(600006);

        Person personOne = new Person();
        personOne.setFirstName("murali");
        personOne.setLastName("murugan");
        personOne.setEmail("murali@gmail.com");
        Date date = Date.valueOf("1996-08-27"); 
        personOne.setBirthDate(date);
        personOne.setAddress(addressOne);

        Address addressTwo = new Address();
        addressTwo.setStreet("tirupalli street");
        addressTwo.setCity("chennai");
        addressTwo.setPostalCode(600008);

        Person personTwo = new Person();
        personTwo.setFirstName("vidhyaa");
        personTwo.setLastName("masilamani");
        personTwo.setEmail("vidhyaa@gmail.com");
        Date anotherDate = Date.valueOf("1997-09-15"); 
        personTwo.setBirthDate(anotherDate);
        personTwo.setAddress(addressTwo);
        
        return new Object[][] {
            {personOne}
            , {personTwo}
        };
    }

    @Test(dataProvider = "testCreateNegativeDP")
    private void testCreateNegative(Person person,
                                    ArrayList<AppErrorCode> expectedErrors) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            personService.create(newConnection, person);
            newConnection.rollback();
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCodes, expectedErrors);
        } finally {
            newConnection.close();
            personService = null;
        }
    }

    @DataProvider
    private Object[][] testCreateNegativeDP() {
        Address address = new Address();
        address.setStreet("govindapa street");
        address.setCity("chennai");
        address.setPostalCode(600006);

        Person person = new Person();
        person.setFirstName("");
        person.setLastName("");
        person.setEmail("");
        Date birthDate = Date.valueOf("1997-05-27"); 
        person.setBirthDate(birthDate);
        person.setAddress(address);

        ArrayList<AppErrorCode> expectedErrors = new ArrayList<>();
        expectedErrors.add(AppErrorCode.INVALID_FIRST_NAME);
        expectedErrors.add(AppErrorCode.INVALID_LAST_NAME);
        expectedErrors.add(AppErrorCode.INVALID_EMAIL_ADDRESS);
//        expectedErrors.add(CustomError.DUPLICATE_EMAIL_ID);
//        expectedErrors.add(CustomError.DUPLICATED_FIRST_NAME_AND_LAST_NAME);

        return new Object[][] {
            {person, expectedErrors}
        };
    }

    @Test(dataProvider = "testCreateNegative_FirstNameDP")
    private void testCreateNegative_FirstName(Person person,
                                    ArrayList<AppErrorCode> expectedErrors) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            personService.create(newConnection, person);
            newConnection.rollback();
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCodes, expectedErrors);
            
        } finally {
            newConnection.close();
        }
    }

    @DataProvider
    private Object[][] testCreateNegative_FirstNameDP() {
        Address address = new Address();
        address.setStreet("govindapa street");
        address.setCity("chennai");
        address.setPostalCode(600006);

        Person person = new Person();
        person.setFirstName("");
        person.setLastName("kumar");
        person.setEmail("kumar@gmail.com");
        Date birthDate = Date.valueOf("1997-05-27"); 
        person.setBirthDate(birthDate);
        person.setAddress(address);

        ArrayList<AppErrorCode> expectedErrors = new ArrayList<>();
        expectedErrors.add(AppErrorCode.INVALID_FIRST_NAME);

        return new Object[][] {
            {person, expectedErrors}
        };
    }

    @Test(dataProvider = "testCreateNegative_LastNameDP")
    private void testCreateNegative_LastName(Person person,
                                    ArrayList<AppErrorCode> expectedErrors) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            personService.create(newConnection, person);
            newConnection.rollback();
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCodes, expectedErrors);
            
        } finally {
            newConnection.close();
        }
    }

    @DataProvider
    private Object[][] testCreateNegative_LastNameDP() {
        Address address = new Address();
        address.setStreet("govindapa street");
        address.setCity("chennai");
        address.setPostalCode(600006);

        Person person = new Person();
        person.setFirstName("kumar");
        person.setLastName("");
        person.setEmail("kumar@gmail.com");
        Date birthDate = Date.valueOf("1997-05-27"); 
        person.setBirthDate(birthDate);
        person.setAddress(address);

        ArrayList<AppErrorCode> expectedErrors = new ArrayList<>();
        expectedErrors.add(AppErrorCode.INVALID_LAST_NAME);

        return new Object[][] {
            {person, expectedErrors}
        };
    }

    @Test(dataProvider = "testCreateNegative_EmailDP")
    private void testCreateNegative_Email(Person person,
                                    ArrayList<AppErrorCode> expectedErrors) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            personService.create(newConnection, person);
            newConnection.rollback();
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCodes, expectedErrors);
            
        } finally {
            newConnection.close();
        }
    }

    @DataProvider
    private Object[][] testCreateNegative_EmailDP() {
        Address address = new Address();
        address.setStreet("govindapa street");
        address.setCity("chennai");
        address.setPostalCode(600006);

        Person person = new Person();
        person.setFirstName("ramesh");
        person.setLastName("kumar");
        person.setEmail("");
        Date birthDate = Date.valueOf("1997-05-27"); 
        person.setBirthDate(birthDate);
        person.setAddress(address);

        ArrayList<AppErrorCode> expectedErrors = new ArrayList<>();
        expectedErrors.add(AppErrorCode.INVALID_EMAIL_ADDRESS);

        return new Object[][] {
            {person, expectedErrors}
        };
    }

    @Test(dataProvider = "testCreateNegative_DuplicateValuesDP")
    private void testCreateNegative_DuplicateValues(Person person,
                                    ArrayList<AppErrorCode> expectedErrors) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            personService.create(newConnection, person);
            newConnection.rollback();
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCodes, expectedErrors);
        } finally {
            newConnection.close();
        }
    }

    @DataProvider
    private Object[][] testCreateNegative_DuplicateValuesDP() {
        Address address = new Address();
        address.setStreet("govindapa street");
        address.setCity("chennai");
        address.setPostalCode(600006);

        Person person = new Person();
        person.setFirstName("kamal");
        person.setLastName("murali");
        person.setEmail("kamal@gmail.com");
        Date birthDate = Date.valueOf("1997-05-27"); 
        person.setBirthDate(birthDate);
        person.setAddress(address);

        ArrayList<AppErrorCode> expectedErrors = new ArrayList<>();
        expectedErrors.add(AppErrorCode.DUPLICATED_FIRST_NAME_AND_LAST_NAME);
        expectedErrors.add(AppErrorCode.DUPLICATE_EMAIL_ID);

        return new Object[][] {
            {person, expectedErrors}
        };
    }

    @Test(dataProvider = "testPositiveUpdateDP")
    private void testPositiveUpdate(Person person) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            Person actualResult = personService.update(newConnection, person);
            Person expectedResult = person;
            newConnection.commit();
            Assert.assertEquals(actualResult, expectedResult);
        } catch (AppException appException) {
            newConnection.rollback();
            Assert.fail("sqlException : " + appException.errorCodes);
        } finally {
            newConnection.close();
        }
    }

    @DataProvider
    private Object[][] testPositiveUpdateDP() {
        Person person = new Person();
        person.setId(8l);
        person.setFirstName("kamal");
        person.setLastName("murali");
        person.setEmail("murali@gmail.com");
        Date anotherDate = Date.valueOf("1997-09-15"); 
        person.setBirthDate(anotherDate);
        person.setAddressId(91l);
        Address address = new Address();
        address.setCity("puducherry");
        person.setAddress(address);
        return new Object[][] {
            {person}
        };
    }

    @Test(dataProvider = "testNegativeUpdate_IdDP")
    private void testNegativeUpdate_Id(Person person) {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            personService.update(newConnection, person);
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCode, AppErrorCode.INVALID_PERSON_ID);
        }
    }

    @DataProvider
    private Object[][] testNegativeUpdate_IdDP() {
        Person person = new Person();
        person.setId(null);
        person.setFirstName("ramesh");
        person.setLastName("kumar");
        person.setEmail("ramesh@gmail.com");
        Date birthDate = Date.valueOf("1997-05-18");
        person.setBirthDate(birthDate);
        return new Object[][] {
            {person}
        };
    }

    @Test(dataProvider = "testNegativeUpdateDP")
    private void testNegativeUpdate(Person person, ArrayList<AppErrorCode> expectedErrors) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            personService.update(newConnection, person);
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e, new AppException(expectedErrors));
        }
    }

    @DataProvider
    private Object[][] testNegativeUpdateDP() {
        Person person = new Person();
        person.setId(3l);
        person.setFirstName("");
        person.setLastName("");
        person.setEmail("");
        Date birthDate = Date.valueOf("1997-05-27");
        person.setBirthDate(birthDate);

        ArrayList<AppErrorCode> expectedErrors = new ArrayList<>();
        expectedErrors.add(AppErrorCode.INVALID_FIRST_NAME);
        expectedErrors.add(AppErrorCode.INVALID_LAST_NAME);
        expectedErrors.add(AppErrorCode.INVALID_EMAIL_ADDRESS);
//        expectedErrors.add(CustomError.INVALID_BIRTH_DATE);
        return new Object[][] {
            {person, expectedErrors}
        };
    }

    @Test(dataProvider = "testPositiveDeleteDP")
    private void testPositiveDelete(Person person) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            long id =  person.getId();
            long actualResult = personService.delete(newConnection, id);
            Person expectedResult = person;
            newConnection.commit();
            Assert.assertEquals(actualResult, expectedResult);
        } catch (AppException e) {
            newConnection.rollback();
            Assert.fail("Errors : " + e.errorCodes);
        } finally {
            newConnection.close();
            personService = null;
        }
    }

    @DataProvider
    private Object[][] testPositiveDeleteDP() {
        Person person = new Person();
        person.setId(58l);
//        person.setFirstName("vigneshh");
//        person.setLastName("murugan");
//        person.setEmail("vigneshh@gmail.com");
//        Date birthDate = Date.valueOf("1997-04-23");
//        person.setBirthDate(birthDate);
        return new Object[][] {
            {person}
        };
    }

    @Test(dataProvider = "testNegativeDeleteDP") 
    private void testNegativeDelete(Person person) throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            long id = person.getId();
            personService.delete(newConnection, id);
            Assert.fail("expected an exception");
            newConnection.rollback();
        } catch (AppException e) {
            newConnection.rollback();
            Assert.assertEquals(e.errorCode, AppErrorCode.INVALID_PERSON_ID);
        } finally {
            newConnection.close();
        }
    }

    @DataProvider 
    private Object[][] testNegativeDeleteDP() {
        Person person = new Person();
        person.setId(0l);
//        person.setFirstName("suresh");
//        person.setLastName("kumar");
//        person.setEmail("suresh@gmail.com");
//        Date birthDate = Date.valueOf("1997-04-23");
//        person.setBirthDate(birthDate);
        return new Object[][] {
            {person}
        };
    }

    @Test(dataProvider = "testPositiveReadWithAddressDP")
    private void testPositiveReadWithAddress(Person person, boolean includeAddress) throws Exception{
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            long id = person.getId();
            Person actualResult = personService.read(newConnection, includeAddress, id);
            Person expectedResult = person;
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (AppException e) {
            Assert.fail(e.getMessage());
        }
    }

    @DataProvider
    private Object[][] testPositiveReadWithAddressDP() {
        Person person = new Person();
        person.setId(64l);
        person.setFirstName("murali");
        person.setLastName("murugan");
        person.setEmail("murali@gmail.com");
        person.setBirthDate(Date.valueOf("1996-08-27"));
        person.setAddressId(61l);
//        person.setCreatedDate(Date.valueOf("2018-09-29 11:26:23");
        Address address = new Address();
        address.setId(61l);
        address.setStreet("parrys street");
        address.setCity("chennai");
        address.setPostalCode(600006);
        person.setAddress(address);
        return new Object[][] {
            {person, true}
        };
    }

    @Test
    private void testNegativeReadWithAddress() throws Exception {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
//            Person person = new Person();
//            person.setId(null);
            long id = 0;
            personService.read(newConnection, true, id);
            Assert.fail("expected an exception");
        } catch (AppException e) {
            Assert.assertEquals(e.errorCode, AppErrorCode.INVALID_PERSON_ID);
        } finally {
            newConnection.close();
        }
    }

    @Test(dataProvider = "testPositiveReadWithOutAddressDP")
    private void testPositiveReadWithOutAddress(Person person, boolean includeAddress) {
        Connection newConnection = null;
        PersonService personService = null;
        try {
            newConnection = ConnectionManager.createConnection();
            personService = new PersonService();
            long id = person.getId();
            Person actualResult = personService.read(newConnection, includeAddress, id);
            Person expectedResult = person;
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    @DataProvider
    private Object[][] testPositiveReadWithOutAddressDP() {
        Person person = new Person();
        person.setId(3l);
        person.setFirstName("vidhya");
        person.setLastName("ramesh");
        person.setEmail("vidhya@gmail.com");
        person.setBirthDate(Date.valueOf("1997-09-15"));
        person.setAddressId(13l);
//        person.setCreatedDate(Date.valueOf(2018-09-29 11:26:23));
        return new Object[][] {
            {person, false}
        };
    }

    @Test(dataProvider = "testPositiveReadAllDP")
    private void testPositiveReadAllWithAddress(ArrayList<Person> person, boolean includeAddress) {
        Connection newConnection = null;
        try {
            PersonService personService = new PersonService();
            newConnection = ConnectionManager.createConnection();
            ArrayList<Person> actualResult = personService.readAll(newConnection, includeAddress);
            ArrayList<Person> expectedResult = person;
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    @DataProvider
    private Object[][] testPositiveReadAllWithAddressDP() {
        ArrayList<Person> records = new ArrayList<>();
        Person person = new Person();
        person.setId(1l);
        person.setFirstName("suresh");
        person.setLastName("kumar");
        person.setEmail("suresh@gmail.com");
        person.setBirthDate(Date.valueOf("1986-08-17"));
        person.setAddressId(new Long(1));
        Address address = new Address();
        address.setStreet("sivam street");
        address.setCity("chennai");
        address.setPostalCode(600502);
        person.setAddress(address);
        records.add(person);
        return new Object[][] {
            {records, true}
        };
    }

    @Test(dataProvider = "testPositiveReadAllWithOutAddressDP")
    private void testPositiveReadAllWithOutAddress(ArrayList<Person> person, boolean includeAddress) {
        Connection newConnection = null;
        try {
            PersonService personService = new PersonService();
            newConnection = ConnectionManager.createConnection();
            ArrayList<Person> actualResult = personService.readAll(newConnection, includeAddress);
            ArrayList<Person> expectedResult = person;
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            
        }
    }

    @DataProvider
    private Object[][] testPositiveReadAllWithOutAddressDP() {
        ArrayList<Person> records = new ArrayList<>();
        Person person = new Person();
        person.setId(new Long(1));
        person.setFirstName("suresh");
        person.setLastName("kumar");
        person.setEmail("suresh@gmail.com");
        person.setBirthDate(Date.valueOf("1986-08-17"));
        person.setAddressId(new Long(1));
        records.add(person);
        return new Object[][] {
            {records, false}
        };
    }

    @AfterClass
    private void tearDown() {
//        personService = null;
    }
}