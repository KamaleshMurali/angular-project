import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'address-list-panel',
  templateUrl: './address-list-panel.component.html',
  styleUrls: ['./address-list-panel.component.css']
})
export class AddressListPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
