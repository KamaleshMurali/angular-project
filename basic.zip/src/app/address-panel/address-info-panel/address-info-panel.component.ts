import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'address-info-panel',
  templateUrl: './address-info-panel.component.html',
  styleUrls: ['./address-info-panel.component.css']
})
export class AddressInfoPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
