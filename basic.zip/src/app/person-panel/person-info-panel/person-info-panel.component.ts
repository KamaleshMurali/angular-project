import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'person-info-panel',
  templateUrl: './person-info-panel.component.html',
  styleUrls: ['./person-info-panel.component.css']
})
export class PersonInfoPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
