import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'person-list-panel',
  templateUrl: './person-list-panel.component.html',
  styleUrls: ['./person-list-panel.component.css']
})
export class PersonListPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
