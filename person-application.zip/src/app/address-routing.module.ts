import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddressListComponent } from './address-list/address-list.component';
import { AddressInfoComponent } from './address-info/address-info.component';

const addressRoutes: Routes = [
    { path: '', component: AddressListComponent, children: [
        { path: 'new', component: AddressInfoComponent},
        { path: ':id', component: AddressInfoComponent},
    ] }
];
@NgModule({
    imports: [
        RouterModule.forChild(addressRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class AddressRoutingModule {}
