import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AddressRoutingModule } from './address-routing.module';
import { AddressListComponent } from './address-list/address-list.component';
import { AddressInfoComponent } from './address-info/address-info.component';

@NgModule({
    declarations: [
        AddressInfoComponent,
        AddressListComponent
    ],
    imports: [
        FormsModule,
        CommonModule,
        AddressRoutingModule
    ]
})
export class AddressModule {}
