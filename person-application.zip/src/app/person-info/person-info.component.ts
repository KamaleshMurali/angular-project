import { Component, OnInit, ViewChild } from '@angular/core';
import { Person } from '../person.model';
import { PersonService } from './../person.service';
import { ActivatedRoute, Params } from '@angular/router';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-person-info',
  templateUrl: './person-info.component.html',
  styleUrls: ['./person-info.component.css']
})
export class PersonInfoComponent implements OnInit {
  @ViewChild('f') detailsForm: NgForm;

    person: Person;
    persons: Person[];
    id: number;
    index: number;
    constructor(private personService: PersonService,
                private router: ActivatedRoute,
                private httpClient: HttpClient) {
        // this.personService.recordSelected.subscribe(
        //     (selectedRecord: Person) => this.person = selectedRecord
        // );
        // this.personService.clearFields.subscribe(
        //   () => this.person = {id: null, firstName: '', lastName: '', email: '', birthDate: ''}
        // );
    }

    ngOnInit() {
        this.getPerson();
    }
    getPerson() {
        this.router.params.subscribe(
            (params: Params) => {
                this.id = +params['id'];
                this.personService.getPerson(this.id).subscribe(
                (data) => {
                    this.person = data;
                    console.log(this.person);
              }
            );
          }
        );
    }

    onSubmit() {
        console.log(this.detailsForm);
        this.person.id = this.detailsForm.value.id;
        this.person.firstName = this.detailsForm.value.firstName;
        this.person.lastName = this.detailsForm.value.lastName;
        this.person.email = this.detailsForm.value.email;
        this.person.birthDate = this.detailsForm.value.dateOfBirth;
        console.log(this.person);
        this.httpClient.put('http://localhost:8080/ws/personServlet', this.person).subscribe(
            (data) => {
                console.log('the put request is successful', data );
                this.personService.addRecord.next(this.person);
            }
        );
        this.detailsForm.reset();
    }

}
