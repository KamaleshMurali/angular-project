import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PersonListComponent } from './person-list/person-list.component';
import { PersonInfoComponent } from './person-info/person-info.component';


const personRoute: Routes = [
    { path: '', component: PersonListComponent, children: [
        { path: 'new', component: PersonInfoComponent},
        { path: ':id', component: PersonInfoComponent}
    ] }
];
@NgModule({
    imports: [
        RouterModule.forChild(personRoute)
    ],
    exports: [
        RouterModule
    ]
})
export class PersonRoutingModule {}
