import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { PersonRoutingModule } from './person-routing.module';
import { PersonListComponent } from './person-list/person-list.component';
import { PersonInfoComponent } from './person-info/person-info.component';

@NgModule({
    declarations: [
        PersonListComponent,
        PersonInfoComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        PersonRoutingModule
    ]
})
export class PersonModule {}
