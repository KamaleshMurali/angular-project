import { Component, OnInit,  OnChanges } from '@angular/core';
import { PersonService } from './../person.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-person-list',
  templateUrl: './person-list.component.html',
  styleUrls: ['./person-list.component.css']
})
export class PersonListComponent implements OnInit, OnChanges {

    personJson: any;
    index: number;

    constructor(private personService: PersonService,
                private router: Router,
                private route: ActivatedRoute) {}

    ngOnInit() {
        this.personService.getPersons().subscribe(
            data => { this.personJson = data; }
        );
        this.personService.addRecord.subscribe(
            (data) => {
                this.personJson.push(data);
            }
        );
    }

    ngOnChanges() {}

    onDeleteRecord(id: number, index: number) {
        this.personService.deletePerson(id).subscribe(
            (data) => {
                this.personJson.splice(index, 1);
                this.router.navigate(['/person'], { relativeTo: this.route});
            },
            (error) => { console.log('record is not deleted'); }
        );
        this.personService.getPersons().subscribe(
            data => { this.personJson = data; }
        );
    }

    onClearFields() {
      this.router.navigate(['new'], {relativeTo: this.route});
    }
}
