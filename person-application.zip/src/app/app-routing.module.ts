import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules} from '@angular/router';

import { LspComponent } from './lsp/lsp.component';

const appRoutes: Routes = [
    { path: '', component: LspComponent, children: [
        { path: 'person', loadChildren: './person.module#PersonModule'},
        { path: 'address', loadChildren: './address.module#AddressModule'}
    ]},
    { path: '', redirectTo: '/', pathMatch: 'full' }
];

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes, { preloadingStrategy: PreloadAllModules})
    ],
    exports: [RouterModule]
})
export class AppRoutingModule { }
