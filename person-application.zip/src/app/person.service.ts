import { EventEmitter, Injectable } from '@angular/core';
import { Person } from './person.model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { ActivatedRoute, Params } from '@angular/router';

@Injectable()
export class PersonService {
    entitySelected = new EventEmitter<string>();
    recordSelected = new EventEmitter<Person>();
    clearFields = new EventEmitter<void>();
    addRecord = new Subject();

    persons: Person[];
    person: Person;
    id: number;
    constructor(private httpClient: HttpClient,
                private router: ActivatedRoute ) {}

    getPersons(): Observable<any> {
        // return this.httpClient.get('./assets/personDetails.json');
        return this.httpClient.get('http://localhost:8080/ws/personServlet');
    }

    getPerson(id: number): Observable<any> {
        return this.httpClient.get('http://localhost:8080/ws/personServlet?id=' + id);
    }

    deletePerson(id: number) {
        return this.httpClient.delete('http://localhost:8080/ws/personServlet?id=' + id);
    }
}
