import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatTabsModule} from '@angular/material/tabs';

@NgModule({
  imports: [
        MatButtonModule,
        MatInputModule,
        MatToolbarModule,
        MatButtonToggleModule,
        MatCheckboxModule,
        MatTabsModule
    ],
  exports: [
        MatButtonModule,
        MatInputModule,
        MatToolbarModule,
        MatButtonToggleModule,
        MatCheckboxModule,
        MatTabsModule
    ]
})

export class MaterialModule { }
