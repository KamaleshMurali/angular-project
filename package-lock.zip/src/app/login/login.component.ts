import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

    @ViewChild('form') loginDetails: NgForm;
    username: string;
    password: string;

    constructor(private router: Router) { }

    ngOnInit() {
    }

    onSubmit() {
        this.username = this.loginDetails.value.username;
        console.log(this.loginDetails);
        this.password = this.loginDetails.value.password;
        console.log(this.password);
        if (this.username != null && this.password != null) {
            this.router.navigate(['/home']);
        }
    }

    showPassword(event) {
        if (event.target.checked) {
        }
    }

    clearFields() {
        this.loginDetails.form.reset();
    }
}
