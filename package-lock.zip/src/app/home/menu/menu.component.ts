import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {

    constructor(private router: Router,
                private routes: ActivatedRoute) { }

    ngOnInit() {
    }

    offers() {
        this.router.navigate(['offers'], { relativeTo: this.routes });
    }

}
