import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-womens',
  templateUrl: './womens.component.html',
  styleUrls: ['./womens.component.scss']
})
export class WomensComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
