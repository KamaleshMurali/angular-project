import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-person-panel',
  templateUrl: './person-panel.component.html',
  styleUrls: ['./person-panel.component.css']
})
export class PersonPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
