import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'person-info',
  templateUrl: './person-info.component.html',
  styleUrls: ['./person-info.component.css']
})
export class PersonInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
