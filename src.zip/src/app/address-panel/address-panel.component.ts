import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-address-panel',
  templateUrl: './address-panel.component.html',
  styleUrls: ['./address-panel.component.css']
})
export class AddressPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
