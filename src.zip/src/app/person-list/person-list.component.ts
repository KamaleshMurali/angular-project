import { Component, OnInit,  OnChanges } from '@angular/core';
import { Person } from '../person.model';
import { PersonService } from 'src/app/person.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-person-list',
  templateUrl: './person-list.component.html',
  styleUrls: ['./person-list.component.css']
})
export class PersonListComponent implements OnInit, OnChanges {

    personJson: any;
    index: number;

    constructor(private personService: PersonService, private router: Router, private route: ActivatedRoute) {}

    ngOnInit() {
        // this.personJson = this.personService.getJson('personDetails.json');
        // console.log(this.personJson);
        this.personService.getPersons().subscribe(
            data => { this.personJson = data; }
        );
        // this.personJson = this.personService.getPerson(this.index);
    }

    ngOnChanges() {
        // this.personService.recordSelected.emit(this.personJson[0]);
    }

    onDeleteRecord(index: number) {
        this.personJson.splice(index, 1);
    }

    onClearFields() {
      // this.personService.clearFields.emit();
      this.router.navigate(['new'], {relativeTo: this.route});
    }
}
