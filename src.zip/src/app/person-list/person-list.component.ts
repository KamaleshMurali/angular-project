import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { Person } from '../person.model';
import { PersonService } from 'src/app/person.service';

@Component({
  selector: 'app-person-list',
  templateUrl: './person-list.component.html',
  styleUrls: ['./person-list.component.css']
})
export class PersonListComponent implements OnInit, OnChanges {

    personJson: Person[];
    index: number;

    constructor(private personService: PersonService) {}

    ngOnInit() {
        // this.personJson = this.personService.getJson('personDetails.json');
        // console.log(this.personJson);
        this.personService.getJson().subscribe(
            data => {this.personJson = data}
        );
        this.personJson = this.personService.getPerson(index);
    }

    ngOnChanges() {
        this.personService.recordSelected.emit(this.personJson[0]);
    }

    onSelectedRow(person: Person) {
        this.personService.recordSelected.emit(person);
    }

    onDeleteRecord(index: number) {
        this.personJson.splice(index, 1);
    }

    onClearFields() {
      this.personService.clearFields.emit();
    }
}
