export class Person {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    birthDate: string;
}
