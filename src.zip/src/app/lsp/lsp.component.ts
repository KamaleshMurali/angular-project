import { Component, OnInit } from '@angular/core';
import { PersonService } from '../person.service';

@Component({
    selector: 'app-lsp-component',
    templateUrl: './lsp.component.html',
    styleUrls: ['./lsp.component.css']
})
export class LspComponent implements OnInit {

    constructor(private personService: PersonService) { }

    ngOnInit() {
      // this.personService.entitySelected.emit('person');
    }
}
