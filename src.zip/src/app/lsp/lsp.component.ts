import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'lsp-component',
  templateUrl: './lsp.component.html',
  styleUrls: ['./lsp.component.css']
})
export class LspComponent implements OnInit {

  // @Output() personSelected = new EventEmitter<string>();
  // @Output() addressSelected =new EventEmitter<string>(); 
  @Output() entitySelected = new EventEmitter<string>();
  constructor() { }

  ngOnInit() {
    this.entitySelected.emit('person');
  }

  loadPanel(panel: string){
    if (panel === 'person') {
      // this.personSelected.emit(panel);
      this.entitySelected.emit(panel);
    } 
    if (panel === 'address') {
      // this.addressSelected.emit(panel);
      this.entitySelected.emit(panel);
    }
  }

}
