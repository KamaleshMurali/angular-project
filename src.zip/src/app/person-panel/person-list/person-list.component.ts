import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { Person } from '../person.model';
import { PersonService } from 'src/app/person.service';

@Component({
  selector: 'app-person-list',
  templateUrl: './person-list.component.html',
  styleUrls: ['./person-list.component.css']
})
export class PersonListComponent implements OnInit, OnChanges {

  @Input() personJson: Person[];
  @Output() selectedRecord = new EventEmitter<Person>();

  constructor(private personService: PersonService) {}

  ngOnInit() {
  }

  ngOnChanges() {
    // this.selectedRecord.emit(this.personJson[0]);
    this.personService.recordSelected.emit(this.personJson[0]);
  }

  onSelectedRow(person: Person) {
    console.log(person);
    this.selectedRecord.emit(person);
  }

  onDeleteRecord(index) {
      this.personJson.splice(index, 1);
  }

  onCreateRecord() {}
}
