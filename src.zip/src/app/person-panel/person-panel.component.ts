import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Person } from './person.model';

@Component({
  selector: 'app-person-panel',
  templateUrl: './person-panel.component.html',
  styleUrls: ['./person-panel.component.css']
})
export class PersonPanelComponent implements OnInit {

    constructor() { }
    // persons: Person[];

    ngOnInit() {
        // this.httpService.get('./assets/personDetails.json').subscribe(
        // data => {
        //     // this.persons = data as string [];
        //     this.persons = data as Person[];
        // },
        // (err: HttpErrorResponse) => {
        //     console.log (err.message);
        // }
        // );
    }
}
