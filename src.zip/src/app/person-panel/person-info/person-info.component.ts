import { Component, OnInit, Input } from '@angular/core';
import { Person } from '../person.model';
import { PersonService } from 'src/app/person.service';

@Component({
  selector: 'app-person-info',
  templateUrl: './person-info.component.html',
  styleUrls: ['./person-info.component.css']
})
export class PersonInfoComponent implements OnInit {

  // @Input() person: Person;
  person: Person;
  constructor(private personService: PersonService) {
    this.personService.recordSelected.subscribe(
      (selectedRecord: Person) => this.person = selectedRecord
    );
  }

  ngOnInit() {
  }

}
