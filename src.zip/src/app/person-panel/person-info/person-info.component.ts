import { Component, OnInit, Input } from '@angular/core';
import { Person } from '../person.model';
import { PersonService } from 'src/app/person.service';

@Component({
  selector: 'app-person-info',
  templateUrl: './person-info.component.html',
  styleUrls: ['./person-info.component.css']
})
export class PersonInfoComponent implements OnInit {

    person: Person;
    constructor(private personService: PersonService) {
        this.personService.recordSelected.subscribe(
            (selectedRecord: Person) => this.person = selectedRecord
        );
        this.personService.clearFields.subscribe(
          () => this.person = {id: null, firstName: '', lastName: '', email: '', dob: ''}
        );
    }

    ngOnInit() {

    }

    onCreateRecord(person: Person) {
      this.person = person;
      console.log(person.id);
    }

}
