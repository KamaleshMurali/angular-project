import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router'
import { PersonListComponent } from './person-panel/person-list/person-list.component';
import { AddressListComponent } from './address-panel/address-list/address-list.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: 'person', component: PersonListComponent },
  { path: 'address', component: AddressListComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
