import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';
import { PersonListComponent } from './person-list/person-list.component';
import { AddressListComponent } from './address-list/address-list.component';
import { PersonInfoComponent } from './person-info/person-info.component';
import { AddressInfoComponent } from './address-info/address-info.component';
import { LspComponent } from './lsp/lsp.component';

const appRoutes: Routes = [
  { path: '', component: LspComponent, children: [
    { path: 'person', component: PersonListComponent, children: [
      { path: 'new', component: PersonInfoComponent},
      { path: ':id', component: PersonInfoComponent}
    ] },
    { path: 'address', component: AddressListComponent, children: [
      { path: ':id', component: AddressInfoComponent}
    ] }
  ]},
  { path: '**', redirectTo: '/', pathMatch: 'full' },
  // { path: 'person', component: PersonListComponent, children: [
  //   { path: ':id', component: PersonInfoComponent}
  // ] },
  // { path: 'address', component: AddressListComponent, children: [
  //   { path: ':id', component: AddressInfoComponent}
  // ] }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
