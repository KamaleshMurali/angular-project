import { EventEmitter, Injectable } from '@angular/core';
import { Person } from './person-panel/person.model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class PersonService {
    entitySelected = new EventEmitter<string>();
    recordSelected = new EventEmitter<Person>();
    clearFields = new EventEmitter<void>();

    persons: Person[];
    constructor(private httpService: HttpClient) {
        this.getJson().subscribe(data => {
            this.persons = data as Person[];
        });
    }
    
    getJson(): Observable<any> {
        return this.httpService.get('./assets/personDetails.json');
    }
}
