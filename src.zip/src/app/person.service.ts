import { EventEmitter, Injectable } from '@angular/core';
import { Person } from './person.model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ActivatedRoute, Params } from '@angular/router';

@Injectable()
export class PersonService {
    entitySelected = new EventEmitter<string>();
    recordSelected = new EventEmitter<Person>();
    clearFields = new EventEmitter<void>();

    persons: Person[];
    person: Person;
    id: number;
    constructor(private httpService: HttpClient,
                private router: ActivatedRoute ) {

    }
    
    getJson(): Observable<any> {
        return this.httpService.get('./assets/personDetails.json');
    }

    getPersons() {
        this.getJson().subscribe(data => {
            this.persons = data as Person[];
        });
    }

    getPerson(index: number) {
        // this.getJson().subscribe(data =>{
        //     this.persons = data as Person[];
        //     console.log(this.person);
        //     this.person = this.persons[index];
        // });
        // return this.person;
        console.log(this.getPersons());
        this.getJson().subscribe(
            (data) => {
              this.persons = data;
              this.router.params.subscribe(
                (params: Params) => {
                  this.id = +params['id'];
                  console.log(this.id);
                  console.log(this.persons);
                  this.person = this.persons[this.id];
                  return this.person;
                }
              )
            });
    }
}
