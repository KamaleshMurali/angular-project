import { EventEmitter, Injectable } from '@angular/core';
import { Person } from './person-panel/person.model';

@Injectable()
export class PersonService {
  entitySelected = new EventEmitter<string>();
  recordSelected = new EventEmitter<Person>();
}
