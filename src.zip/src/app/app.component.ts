import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // personSelected: boolean;
  // addressSelected: boolean;

  // onPersonSelected(person: string) {
  //   this.addressSelected = false;
  //   this.personSelected = true;
  // }
  // onAddressSelected(address: string) {
  //   this.addressSelected = true;
  //   this.personSelected = false;
  // }

  entitySelected: string;
  onEntitySelected(entity: string) {
    this.entitySelected = entity;
  }
}
