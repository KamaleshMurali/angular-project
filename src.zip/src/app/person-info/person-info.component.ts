import { Component, OnInit, Input } from '@angular/core';
import { Person } from '../person.model';
import { PersonService } from 'src/app/person.service';
import { ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-person-info',
  templateUrl: './person-info.component.html',
  styleUrls: ['./person-info.component.css']
})
export class PersonInfoComponent implements OnInit {

    person: Person;
    persons: Person[];
    id: number;
    constructor(private personService: PersonService,
                private router: ActivatedRoute) {
        this.personService.recordSelected.subscribe(
            (selectedRecord: Person) => this.person = selectedRecord
        );
        this.personService.clearFields.subscribe(
          () => this.person = {id: null, firstName: '', lastName: '', email: '', dob: ''}
        );
    }

    ngOnInit() {
        this.personService.getJson().subscribe(
          (data) => {
            this.persons = data;
            this.router.params.subscribe(
              (params: Params) => {
                this.id = +params['id'];
                console.log(this.id);
                console.log(this.persons);
                this.person = this.persons[this.id];
              }
            )
          });
        // this.router.params.subscribe(
        //   (params: Params) => {
        //     this.id = +params['id'];
        //     console.log(this.id);
        //     console.log(this.persons);
        //     this.person = this.persons[this.id];
        //   }
        // )
    }

    onCreateRecord(person: Person) {
      this.person = person;
      console.log(person.id);
    }

}
