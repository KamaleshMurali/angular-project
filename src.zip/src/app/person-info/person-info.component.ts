import { Component, OnInit, Input } from '@angular/core';
import { Person } from '../person.model';
import { PersonService } from 'src/app/person.service';
import { ActivatedRoute, Params } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-person-info',
  templateUrl: './person-info.component.html',
  styleUrls: ['./person-info.component.css']
})
export class PersonInfoComponent implements OnInit {

    person: Person;
    persons: Person[];
    id: number;
    index: number;
    constructor(private personService: PersonService,
                private router: ActivatedRoute) {
        // this.personService.recordSelected.subscribe(
        //     (selectedRecord: Person) => this.person = selectedRecord
        // );
        this.personService.clearFields.subscribe(
          () => this.person = {id: null, firstName: '', lastName: '', email: '', birthDate: ''}
        );
    }

    ngOnInit() {
        this.getPerson();
        // this.router.params.subscribe(
        //   (params: Params) => {
        //     this.id = +params['id'];
        //     console.log(this.id);
        //     console.log(this.persons);
        //     this.person = this.persons[this.id];
        //   }
        // )

    }

    // getPerson() {
    //     this.personService.getPersons().subscribe((data) => {
    //         this.persons = data;
    //         this.router.params.subscribe((params: Params) => {
    //             // this.person.id = +params['id'];
    //             // this.index = this.persons.findIndex(this.person.id);
    //             this.id = +params['id'];
    //             console.log(this.id);
    //             console.log(this.persons);
    //             this.person = this.persons[this.id];
    //             console.log(this.person);
    //         });
    //     });
    // }

    getPerson() {
        this.router.params.subscribe(
          (params: Params) => {
            this.id = +params['id'];
            this.personService.getPerson(this.id).subscribe(
              (data) => {
                this.person = data;
              }
            );
          }
        );
    }

    onCreateRecord(event: Event) {
        console.log(event);
        // this.personService.addRecord.next(person);
    }

    onSubmit(f: NgForm) {
      console.log(f);
    }

}
